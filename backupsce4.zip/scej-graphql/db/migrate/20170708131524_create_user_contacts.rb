class CreateUserContacts < ActiveRecord::Migration[5.1]
  def change
    create_table :user_contacts do |t|
      t.integer :position
      t.string :slug
      t.string :first_name
      t.string :last_name
      t.string :email
      t.string :phone
      t.string :mobile
      t.integer :salary, :default => 0

      t.timestamps
    end
    add_index :user_contacts, :position
    add_index :user_contacts, :slug, unique: true
    add_index :user_contacts, :email, unique: true
  end
end
