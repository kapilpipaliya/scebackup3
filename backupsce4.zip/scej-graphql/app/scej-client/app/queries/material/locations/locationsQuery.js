import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  location: gql`
    fragment LocationPreviewFragment on MaterialLocation {
      id
      position
      slug
      location
      isdefault
      created_at
    }
  `,
};

export const AllLocationsQuery = gql`
  query allMaterialLocationsQuery {
    locationsCount
    allMaterialLocations {
      ...LocationPreviewFragment
    }
  }
  ${fragments.location}
`;

export default graphql(AllLocationsQuery, {
  name: 'locations',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
