import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  mfgTxn: gql`
    fragment MfgTxnPreviewFragment on MfgMfgTxn {
      id
      position
      mfg_date
      casting_id { id slug }
      job_id { id }
      location_id { id slug }
      department
      entry_by_id { id slug }
      description
      issue_weight
      is_customer_stock
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      t_issue
      t_issue_pure
      receive_weight
      receive_pure_weight
      final_receive_wt
      received
      final_receive_pure_wt
      dust_weight
      loss
      loss_pure
      created_at
    }
  `,
};

export const AllMfgTxnsQuery = gql`
  query allMfgMfgTxnsQuery {
    mfgTxnsCount
    allMfgMfgTxns {
      ...MfgTxnPreviewFragment
    }
  }
  ${fragments.mfgTxn}
`;

export default graphql(AllMfgTxnsQuery, {
  name: 'mfgtxns',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
