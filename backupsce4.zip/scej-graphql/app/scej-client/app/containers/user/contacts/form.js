
import validatorjs from 'validatorjs';

export default {
  plugins: { dvr: validatorjs },
  options: {
  },
  fields: [
  "position",
  "slug",
  "first_name",
  "last_name",
  "email",
  "phone",
  "mobile",
  "salary"
],
  initials: {
  "salary": 0
},
  labels: {
  "position": "SN#",
  "slug": "Code",
  "first_name": "First name",
  "last_name": "Last name",
  "email": "Email",
  "phone": "Phone",
  "mobile": "Mobile",
  "salary": "Salary"
},
  placeholders: {
  "position": "Position",
  "slug": "Slug",
  "first_name": "First name",
  "last_name": "Last name",
  "email": "Email",
  "phone": "Phone",
  "mobile": "Mobile",
  "salary": "Salary"
},
  types: {
  "position": "number",
  "slug": "text",
  "first_name": "text",
  "last_name": "text",
  "email": "email",
  "phone": "text",
  "mobile": "text",
  "salary": "number"
},
  rules: {
  "position": "",
  "slug": "",
  "first_name": "",
  "last_name": "",
  "email": "",
  "phone": "",
  "mobile": "",
  "salary": ""
},
  hooks: {
    onSuccess(form) {
      alert('Form is valid! Send the request here.');
      // get field values
      console.log('Form Values!', form.values());
    },
    onError(form) {
      alert('Form has errors!');
      // get all form errors
      console.log('All form errors', form.errors());
    }
  },
  bindings: {
}
}
