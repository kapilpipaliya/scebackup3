import React, { Component } from 'react';
import Button from 'material-ui/Button';
import AddressForm from './_AddressForm';
import withCreateAddress from '../../../mutations/user/addresses/createAddressMutation';

class NewAddress extends Component {
  render() {
    return (
      <div>
        <h1>New Address</h1>
        <AddressForm action={this.props.createAddress} submitName="Create Address" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateAddress(NewAddress);
