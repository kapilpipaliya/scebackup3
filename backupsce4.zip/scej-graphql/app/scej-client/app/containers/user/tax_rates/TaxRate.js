import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withTaxRate from '../../../queries/user/tax_rates/taxRateQuery';

class TaxRate extends Component {
  render() {
    const { taxRate, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="taxRate">
        <p>TaxRate</p>
        <h2 className="taxRate-heading">{taxRate.slug}</h2>
        <div className="taxRate-meta">
          <span className="taxRate-author">
            Posted by: <em>{/* {taxRate.author.name} */}</em>
          </span>
          <span className="taxRate-date">
            {moment(new Date(taxRate.created_at)).fromNow()}
          </span>
        </div>
        <div className="taxRate-content">
          contents display here: ID : {taxRate.id}
        </div>
      </article>
    );
  }
}

export default withTaxRate(TaxRate);
