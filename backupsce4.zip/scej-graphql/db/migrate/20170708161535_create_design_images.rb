class CreateDesignImages < ActiveRecord::Migration[5.1]
  def change
    create_table :design_images do |t|
      t.references :imageable, polymorphic: true
      t.string :image

      t.timestamps
    end
  end
end
