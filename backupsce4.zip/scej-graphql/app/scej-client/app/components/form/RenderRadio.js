import React from 'react';
import PropTypes from 'prop-types';
// Material-Ui
import Radio from 'material-ui/Radio';

// Redux-form Material Ui example is different way.
const RenderRadio = (props) => (
  <Radio {...props.input} />
);

RenderRadio.propTypes = {
  input: PropTypes.object,
};
export default RenderRadio;
