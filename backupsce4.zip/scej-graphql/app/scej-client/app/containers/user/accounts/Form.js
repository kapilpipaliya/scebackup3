import React from 'react';
import { observer } from 'mobx-react';
import _ from 'lodash';
import Grid from 'material-ui/Grid';
import { withApollo } from 'react-apollo';
import FormControls from '../../../components/controls/FormControls';
import MaterialTextField from '../../../components/inputs/MaterialTextField';
import SimpleSelectMaterial from '../../../components/inputs/SimpleSelectMaterial';

import { AllAccountTypesQuery } from '../../../queries/user/account_types/accountTypesQuery';
import { AllRolesQuery } from '../../../queries/user/roles/rolesQuery';
// Part1
// Part1

@withApollo
@observer
class Form extends React.Component {
  componentDidMount() {
    this._componenDidMount();
  }
  async _componenDidMount() {
    this.fetchAccountTypes('account_type_id', 1)
    this.fetchRoles('role_id', 1)
  }

  fetchAccountTypes = async (field ) => {
    const accountTypes = await this.props.client.query({
      query: AllAccountTypesQuery,
      variables: {},
    });
    this.props.form.set('extra', {
      [field]: _.mapKeys(accountTypes.data.allUserAccountTypes, (value) => value.id)
    })
  }

  fetchRoles = async (field ) => {
    const roles = await this.props.client.query({
      query: AllRolesQuery,
      variables: {},
    });
    this.props.form.set('extra', {
      [field]: _.mapKeys(roles.data.allUserRoles, (value) => value.id)
    })
  }
// Part2
// Part2

  render(){
  
  const {form, action} = this.props;
  
  // if(this.props.initialValues) {
  //   form.set('value', this.props.initialValues)
  // }
  
  const hooks = {
    onSuccess(form) {
      // alert('submitting....');

      return action(form.values()).then((errors) => {
        if (errors) {
          form.set('error', errors);
          
          Object.keys(errors).forEach((v) => {
            form.$(v).invalidate(errors[v])
          });
          // form.invalidate('This is a generic error message!');
          
        } else {
          form.clear()
        }
      })
    }
  }
    
  return(
    <form>
      <fieldset>
        <Grid container spacing={24}>
          <Grid item xs={12}><SimpleSelectMaterial field={form.$('account_type_id')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('position')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('slug')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('join_date')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('company_name')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('first_name')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('last_name')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('phone')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('mobile')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('salary')} /></Grid>
          <Grid item xs={12}><SimpleSelectMaterial field={form.$('role_id')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('email')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('encrypted_password')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('reset_password_token')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('reset_password_sent_at')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('remember_created_at')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('sign_in_count')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('current_sign_in_at')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('last_sign_in_at')} /></Grid>


        </Grid>
        <FormControls form={form} hooks={hooks}/>
      </fieldset>
    </form>
  )}
}

export default Form;
