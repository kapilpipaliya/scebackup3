export default {
  currentUser(state = [], { mutationResult }) {
    const { signUp } = mutationResult.data;

    if (signUp) {
      const { currentUser } = signUp;
      if (!currentUser) {
        return null;
      }
      return { currentUser };
    }

    return state;
  },
};
