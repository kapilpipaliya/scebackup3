import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  metalPurity: gql`
    fragment MetalPurityForEditingFragment on MaterialMetalPurity {
      id
      material_id { id slug }
      position
      slug
      name
      purity
      specific_density
      price
      description
    }
  `,
};

export default function (WrappedComponent) {
  const GET_METAL_PURITY = gql`
    query getMetalPurity($id: ID) {
      metalPurity(id: $id) {
        ...MetalPurityForEditingFragment
      }
    }
    ${fragments.metalPurity}
  `;

  const withMetalPurityForEditing = graphql(GET_METAL_PURITY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMetalPurityForEditing(WrappedComponent);
}
