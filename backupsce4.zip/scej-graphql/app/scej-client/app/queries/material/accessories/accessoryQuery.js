import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  accessory: gql`
    fragment AccessoryFragment on MaterialAccessory {
      id
      position
      slug
      accessory
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_ACCESSORY = gql`
    query getAccessory($id: ID) {
      accessory(id: $id) {
        ...AccessoryFragment
      }
    }
    ${fragments.accessory}
  `;

  const withAccessory = graphql(GET_ACCESSORY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withAccessory(WrappedComponent);
}
