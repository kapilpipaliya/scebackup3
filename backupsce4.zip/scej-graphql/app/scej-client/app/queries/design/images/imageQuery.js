import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  image: gql`
    fragment ImageFragment on DesignImage {
      id
      imageable_type
      imageable_id { id slug }
      image
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_IMAGE = gql`
    query getImage($id: ID) {
      image(id: $id) {
        ...ImageFragment
      }
    }
    ${fragments.image}
  `;

  const withImage = graphql(GET_IMAGE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withImage(WrappedComponent);
}
