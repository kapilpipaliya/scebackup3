import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  locker: gql`
    fragment LockerForEditingFragment on MaterialLocker {
      id
      location_id { id slug }
      position
      slug
      locker
      isdefault
    }
  `,
};

export default function (WrappedComponent) {
  const GET_LOCKER = gql`
    query getLocker($id: ID) {
      locker(id: $id) {
        ...LockerForEditingFragment
      }
    }
    ${fragments.locker}
  `;

  const withLockerForEditing = graphql(GET_LOCKER, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withLockerForEditing(WrappedComponent);
}
