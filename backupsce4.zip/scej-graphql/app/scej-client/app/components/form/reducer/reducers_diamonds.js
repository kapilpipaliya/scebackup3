export default function (previousState = {
  materials: {}, gemshapes: {}, gemclarities: {}, colors: {}, gemsizes: {},
}, action) {
  let n = {};
  switch (action.type) {
    case 'DIAMONDS_FETCH_MATERIALS':
      n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n.materials[action.row] = v;
      });
      return n;
    case 'FETCH_ALL_MATERIALS_CHANGE':
      n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n.gemshapes[action.row] = v.gemshapes;
        n.gemclarities[action.row] = v.gemclarities;
        n.colors[action.row] = v.colors;
      });
      return n;
    case 'FETCH_ALL_SHAPE_OR_CLARITY_CHANGE':
      n = Object.assign({}, previousState);
      action.payload.then((v) => { n.gemsizes[action.row] = v; });
      return n;
    default:
      break;
  }
  return previousState;
}

// in rootReducer.js file.
// import diamonds_Reducer from '../components/form/reducer/reducers_diamonds';
// diamonds: diamonds_Reducer,
