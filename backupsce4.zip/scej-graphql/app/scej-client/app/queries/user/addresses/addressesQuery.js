import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  address: gql`
    fragment AddressPreviewFragment on UserAddress {
      id
      account_id { id slug }
      position
      firstname
      lastname
      address1
      address2
      city
      zipcode
      state_id { id slug }
      country_id { id slug }
      phone
      alternative_phone
      company
      created_at
    }
  `,
};

export const AllAddressesQuery = gql`
  query allUserAddressesQuery {
    addressesCount
    allUserAddresses {
      ...AddressPreviewFragment
    }
  }
  ${fragments.address}
`;

export default graphql(AllAddressesQuery, {
  name: 'addresses',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
