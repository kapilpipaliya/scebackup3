import React, { Component } from 'react';
import ListTaxRates from './_ListTaxRates';
import HeadListTaxRates from './_HeadListTaxRates';
import withTaxRatesData from '../../../queries/user/tax_rates/taxRatesQuery';

class SearchTaxRates extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.taxRates = [];
    }
  }

  render() {
    const { taxRates, taxRatesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreTaxRates,
      firstTaxRatesLoading,
    } = this.props;

    return (
      <div className="search-taxRates">
        <h1>Searching taxRates</h1>
        <HeadListTaxRates
          initialKeywords={keywords}
          loading={firstTaxRatesLoading}
        />

        {!firstTaxRatesLoading && taxRates && taxRates.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListTaxRates
            taxRates={taxRates}
            taxRatesCount={taxRatesCount}
            loading={loading}
            loadMoreTaxRates={loadMoreTaxRates}
          />
        )}
      </div>
    );
  }
}

export default withTaxRatesData(SearchTaxRates);
