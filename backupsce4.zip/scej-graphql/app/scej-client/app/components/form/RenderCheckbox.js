import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import Checkbox from 'material-ui/Checkbox';
import { FormControl, FormHelperText } from 'material-ui/Form';

const styles = (theme) => ({
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    // width: 200,
  },
});

class RenderField extends Component {
  static propTypes = {
    input: PropTypes.object.isRequired,
    meta: PropTypes.object.isRequired,
    onChange2: PropTypes.func,
  };

   input = () => {
     const {
       meta: { touched, error, invalid },
       input,
       // input: { name },
       // type,
       // rows,
       // placeholder,
       onChange2,
       // ...custom // This is Proper Format for Custom properties in this.props. It includes not included properties.!!
     } = this.props;
     // const { classes } = this.props;
     const inputChange = (event, checked) => {
       input.onChange(checked);
       // const v = e.target.value==="true"
       if (onChange2) {
         onChange2(checked);
       }
     };
     // <FormControl component="fieldset">
     return (
       <FormControl>
         <Checkbox
           // error={touched && invalid}
           // type={type}
           // id={name}
           // label={this.state.label}
           // placeholder={placeholder}
           name={input.name}
           onBlur={input.onBlur}
           // onChange= {input.onChange}
           onDragStart={input.onDragStart}
           onDrop={input.onDrop}
           onFocus={input.onFocus}
           // value= {input.value}  // value should string.
           onChange={inputChange}
         />
         {touched &&
        error &&
        <FormHelperText error={touched && invalid}>
          {touched && error}
        </FormHelperText>}
       </FormControl>
     );
   }

   render() {
     return (this.input());
   }
}

export default withStyles(styles)(RenderField);
