import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  materialType: gql`
    fragment MaterialTypeFragment on MaterialMaterialType {
      id
      position
      slug
      material_type
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_MATERIAL_TYPE = gql`
    query getMaterialType($id: ID) {
      materialType(id: $id) {
        ...MaterialTypeFragment
      }
    }
    ${fragments.materialType}
  `;

  const withMaterialType = graphql(GET_MATERIAL_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMaterialType(WrappedComponent);
}
