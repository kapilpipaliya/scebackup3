import React from 'react';
import { observer } from 'mobx-react';
import _ from 'lodash';
import Grid from 'material-ui/Grid';
import { withApollo } from 'react-apollo';
import FormControls from '../../../components/controls/FormControls';
import MaterialTextField from '../../../components/inputs/MaterialTextField';


// Part1
// Part1

@withApollo
@observer
class Form extends React.Component {
  componentDidMount() {
    this._componenDidMount();
  }
  async _componenDidMount() {

  }

// Part2
// Part2

  render(){
  
  const {form, action} = this.props;
  
  // if(this.props.initialValues) {
  //   form.set('value', this.props.initialValues)
  // }
  
  const hooks = {
    onSuccess(form) {
      // alert('submitting....');

      return action(form.values()).then((errors) => {
        if (errors) {
          form.set('error', errors);
          
          Object.keys(errors).forEach((v) => {
            form.$(v).invalidate(errors[v])
          });
          // form.invalidate('This is a generic error message!');
          
        } else {
          form.clear()
        }
      })
    }
  }
    
  return(
    <form>
      <fieldset>
        <Grid container spacing={24}>
          <Grid item xs={12}><MaterialTextField field={form.$('position')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('slug')} /></Grid>
        </Grid>
        <FormControls form={form} hooks={hooks}/>
      </fieldset>
    </form>
  )}
}

export default Form;
