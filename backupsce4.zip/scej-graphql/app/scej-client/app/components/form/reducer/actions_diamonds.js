// Utilites
// React-Apollo
import { fexecuteM, fexecuteMChange, fexecuteShapeorClarityChange } from '../../../utils/Fetch';

// ==================ACTIONS==================================
export function diamondsFetchMaterials(aClient, id, row) {
  const request = fexecuteM(aClient, id);
  return {
    type: 'DIAMONDS_FETCH_MATERIALS',
    payload: request,
    row,
  };
}

export function fetchMaterialChange(aClient, mID, row) {
  const request = fexecuteMChange(aClient, mID);
  return {
    type: 'FETCH_ALL_MATERIALS_CHANGE',
    payload: request,
    row,
  };
}

export function fetchShapeOrClarityChange(aClient, mID, shapeId, clarityId, row) {
  const request = fexecuteShapeorClarityChange(aClient, mID, shapeId, clarityId);
  return {
    type: 'FETCH_ALL_SHAPE_OR_CLARITY_CHANGE',
    payload: request,
    row,
  };
}
