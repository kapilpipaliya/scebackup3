import React from 'react';

const HOCFetch = (InnerComponent) => class extends React.Component {
  autoPosition = () => {
    // Fetch all records. and dispatch new position.
  };
  checkboxToogle = (row) => {
    const name = `${this.props.fields.name}[${row}]`;
    this.props.change(`${name}.position`, '');
  };
  materialChange = async (row, value) => {
    this.props.a.orderFetchMetalPurities(this.props.client, value, row);
    this.props.a.orderFetchColors(this.props.client, value, row);
  };
  qtyChange = async (row, qty) => {
    const style = this.props.o.jobStyleComplete[row];
    const name = `${this.props.fields.name}[${row}]`;
    this.props.change(`${name}.net_weight`, style.net_weight * qty);
    this.props.change(`${name}.pure_weight`, style.pure_weight * qty);
    this.props.change(`${name}.diamond_pcs`, style.diamond_pcs * qty);
    this.props.change(`${name}.diamond_weight`, style.diamond_weight * qty);
    this.props.change(`${name}.cs_pcs`, style.cs_pcs * qty);
    this.props.change(`${name}.cs_weight`, style.cs_weight * qty);
    this.props.change(`${name}.gross_weight`, style.gross_weight * qty);

    const styleDiamonds = this.props.o.jobStyleComplete[row].diamonds;
    const newDiamonds = styleDiamonds.map((obj) => {
      // clone the current object
      const newObj = Object.assign({}, obj);
      // update the new object
      newObj.pcs = obj.pcs * qty;
      newObj.pointer = obj.pointer * qty;
      newObj.weight = obj.weight * qty;
      return newObj;
    });
    this.props.change(`${name}.diamonds`, newDiamonds);
  };
  purityChange = async (row, v) => {
    const style = this.props.o.jobStyleComplete[row];
    const name = `${this.props.fields.name}[${row}]`;
    if (v) {
      const purity = this.props.o.jobMetalPurities[row][v];
      const { qty } = this.props.jobs[row];
      const newNetWt = purity.specific_density * style.volume * qty;
      this.props.change(`${name}.net_weight`, newNetWt);
      this.props.change(`${name}.pure_weight`, (purity.purity * newNetWt) / 100);
      this.props.change(`${name}.gross_weight`, newNetWt + ((this.props.total_d_wt + this.props.total_cs_weight) / 5));
    } else {
      this.props.change(`${name}.purity_per`, 0);
      this.props.change(`${name}.pure_weight`, 0);
      this.props.change(`${name}.volume`, 0);
    }
    // TODO Refresh Summery()
  };

  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
        fetchIndex={this.executeGeneral}
        fetchMChange={this.executeMChange}
        fetchShClChange={this.executeShapeorClarityChange}
        delIndex={this.delIndex}
      />
    );
  }
};

export default HOCFetch;
