import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  style: gql`
    fragment StylePreviewFragment on DesignStyle {
      id
      position
      slug
      collection_id { id slug }
      making_type_id { id slug }
      setting_type_id { id slug }
      designer_id { id slug }
      material_id { id slug }
      metal_purity_id { id slug }
      color_id { id slug }
      net_weight
      purity_per
      pure_weight
      volume
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      description
      active
      created_at
    }
  `,
};

export const AllStylesQuery = gql`
  query allDesignStylesQuery {
    stylesCount
    allDesignStyles {
      ...StylePreviewFragment
    }
  }
  ${fragments.style}
`;

export default graphql(AllStylesQuery, {
  name: 'styles',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
