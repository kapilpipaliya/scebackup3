import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  image: gql`
    fragment ImageForEditingFragment on DesignImage {
      id
      imageable_type
      imageable_id { id slug }
      image
    }
  `,
};

export default function (WrappedComponent) {
  const GET_IMAGE = gql`
    query getImage($id: ID) {
      image(id: $id) {
        ...ImageForEditingFragment
      }
    }
    ${fragments.image}
  `;

  const withImageForEditing = graphql(GET_IMAGE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withImageForEditing(WrappedComponent);
}
