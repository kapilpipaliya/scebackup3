import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import { FormControl, FormHelperText } from 'material-ui/Form';
import Input, { InputLabel } from 'material-ui/Input';
import NumberFormat from 'react-number-format';
import capitalize from '../../utils/stringEnhancer';
/* eslint-disable */
class NumberFormatCustom extends React.Component {
  render() {
    return (
      <NumberFormat {...this.props} decimalScale={3} fixedDecimalScale />
    );
  }
}
NumberFormatCustom.propTypes = {
  onChange: PropTypes.func.isRequired,
};

const styles = (theme) => ({
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    // width: 200,
  },
});

class RenderInput extends Component {
  static propTypes = {
    input: PropTypes.object.isRequired,
    meta: PropTypes.object.isRequired,
    type: PropTypes.string,
    rows: PropTypes.number,
    placeholder: PropTypes.string,
    label: PropTypes.string,
    initialValue: PropTypes.object,
    hint: PropTypes.string,
    onChange2: PropTypes.func,
    visible: PropTypes.bool,
  };
 /* eslint-enable */
  static defaultProps = {
    // type: 'text',
    rows: 6,
    placeholder: '',
    label: '',
  };

  constructor(props) {
    super(props);
    const { label, input: { name } } = this.props;
    this.state = { label: label || capitalize(name) };
    this.input = this.input.bind(this);
  }

  input() {
    const {
      meta: { touched, error, invalid },
      input,
      input: { name },
      type,
      rows,
      placeholder,
      onChange2,
      ...custom
    } = this.props;
    if (custom) {
      custom.classes = undefined;
    } // This Key Making Problems.
    // const {classes} = this.props;

    const inputChange = (e) => {
      input.onChange(e);
      if (onChange2) {
        onChange2(e.target.value);
      }
    };
    const inputChangeNumber = (values) => {
      input.onChange(values.floatValue);
      if (onChange2) {
        onChange2(values.floatValue);
      }
    };

    if (this.props.visible === false) {
      return <span></span>;
    }
    if (custom) {
      custom.visible = undefined;
    } // This Key Making Problems.

    if (type === 'textarea') {
      return (
        <Input
          error={touched && invalid}
          type={type}
          rows={rows}
          id={name}
          label={this.state.label}
          placeholder={placeholder}
          multiline
          // {...input}
          name={input.name}
          onBlur={input.onBlur}
          // onChange= {input.onChange}
          onDragStart={input.onDragStart}
          onDrop={input.onDrop}
          onFocus={input.onFocus}
          value={input.value}
          onChange={inputChange}
          {...custom}
          fullWidth
        />
      );
    }

    return (
      <FormControl error={touched && invalid}>
        {this.props.label && <InputLabel htmlFor={name}>{this.state.label}</InputLabel>}
        <Input
          error={touched && invalid}
          // type={type}
          id={name}
          label={this.state.label}
          placeholder={placeholder}
          name={input.name}
          onBlur={input.onBlur}
          // onChange= {input.onChange}
          onDragStart={input.onDragStart}
          onDrop={input.onDrop}
          onFocus={input.onFocus}
          value={input.value}
          onChange={inputChange}
          {...custom}
          fullWidth
          inputComponent={NumberFormatCustom}
          inputProps={{ onValueChange: inputChangeNumber }}
        />
        {touched &&
        error &&
        <FormHelperText error={touched && invalid}>
          {touched && error}
        </FormHelperText>}
      </FormControl>
    );
  }

  render() {
    return (this.input());
  }
}

export default withStyles(styles)(RenderInput);
