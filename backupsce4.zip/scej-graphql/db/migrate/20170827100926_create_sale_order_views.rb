class CreateSaleOrderViews < ActiveRecord::Migration[5.1]
  def up
    self.connection.execute %Q( CREATE VIEW public.sale_order_views
      AS
      SELECT
        sale_orders.id,
        sale_orders."position",
        sale_orders.customer_id,
        sale_orders.taken_by_id,
        sale_orders.order_date,
        sale_orders.delivery_date,
        sale_orders.mfg_product_type_id,
        sale_orders.description,
        count(*) AS items,
        sale_orders.created_at,
        sale_orders.updated_at
      FROM sale_orders, sale_jobs
      WHERE
        (sale_orders.id = sale_jobs.processable_id)
      GROUP BY
        sale_orders.id;
        )
  end

  def down
    self.connection.execute "DROP VIEW IF EXISTS public.sale_order_views;"
  end
end