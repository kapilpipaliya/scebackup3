import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  mTxnType: gql`
    fragment MTxnTypeForEditingFragment on SaleMTxnType {
      id
      position
      slug
      txn_type
    }
  `,
};

export default function (WrappedComponent) {
  const GET_M_TXN_TYPE = gql`
    query getMTxnType($id: ID) {
      mTxnType(id: $id) {
        ...MTxnTypeForEditingFragment
      }
    }
    ${fragments.mTxnType}
  `;

  const withMTxnTypeForEditing = graphql(GET_M_TXN_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMTxnTypeForEditing(WrappedComponent);
}
