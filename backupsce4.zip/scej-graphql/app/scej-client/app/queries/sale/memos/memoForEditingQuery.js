import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  memo: gql`
    fragment MemoForEditingFragment on SaleMemo {
      id
      position
      date
      description
    }
  `,
};

export default function (WrappedComponent) {
  const GET_MEMO = gql`
    query getMemo($id: ID) {
      memo(id: $id) {
        ...MemoForEditingFragment
      }
    }
    ${fragments.memo}
  `;

  const withMemoForEditing = graphql(GET_MEMO, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMemoForEditing(WrappedComponent);
}
