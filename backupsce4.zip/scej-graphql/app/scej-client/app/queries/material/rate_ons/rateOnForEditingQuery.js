import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  rateOn: gql`
    fragment RateOnForEditingFragment on MaterialRateOn {
      id
      material_type_id { id slug }
      position
      slug
      rateon
    }
  `,
};

export default function (WrappedComponent) {
  const GET_RATE_ON = gql`
    query getRateOn($id: ID) {
      rateOn(id: $id) {
        ...RateOnForEditingFragment
      }
    }
    ${fragments.rateOn}
  `;

  const withRateOnForEditing = graphql(GET_RATE_ON, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withRateOnForEditing(WrappedComponent);
}
