import AllAddresses from './AllAddresses';
import SearchAddresses from './SearchAddresses';
import Address from './Address';
import NewAddress from './NewAddress';
import EditAddress from './EditAddress';

export {
  AllAddresses,
  SearchAddresses,
  Address,
  NewAddress,
  EditAddress,
};
