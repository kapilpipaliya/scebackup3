import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  materialType: gql`
    fragment MaterialTypeForEditingFragment on MaterialMaterialType {
      id
      position
      slug
      material_type
    }
  `,
};

export default function (WrappedComponent) {
  const GET_MATERIAL_TYPE = gql`
    query getMaterialType($id: ID) {
      materialType(id: $id) {
        ...MaterialTypeForEditingFragment
      }
    }
    ${fragments.materialType}
  `;

  const withMaterialTypeForEditing = graphql(GET_MATERIAL_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMaterialTypeForEditing(WrappedComponent);
}
