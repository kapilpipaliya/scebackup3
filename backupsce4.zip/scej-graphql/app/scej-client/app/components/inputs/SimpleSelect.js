import React from 'react';
import { observer } from 'mobx-react';
import _ from 'lodash';

  function renderOptions(extra) {
    // The Magical Lodash
    return _.map(extra, (option) => (
      <option key={parseInt(option.id, 10)} value={parseInt(option.id, 10)}>
      {option['slug']}
      </option>
    ));
  }
  
export default observer(({ field }) => (
  <div className="measure">
    <label
      htmlFor={field.id}
      className="f7 db mb2 mt3 light-silver"
    >
      {field.label}
    </label>
    <select {...field.bind()}>
      {renderOptions(field.extra)}
    </select>
  </div>
));
