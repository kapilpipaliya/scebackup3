import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  company: gql`
    fragment CompanyForEditingFragment on UserCompany {
      id
      contact_id { id slug }
      position
      slug
      company
      name
      email
      address
      gst_no
    }
  `,
};

export default function (WrappedComponent) {
  const GET_COMPANY = gql`
    query getCompany($id: ID) {
      company(id: $id) {
        ...CompanyForEditingFragment
      }
    }
    ${fragments.company}
  `;

  const withCompanyForEditing = graphql(GET_COMPANY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withCompanyForEditing(WrappedComponent);
}
