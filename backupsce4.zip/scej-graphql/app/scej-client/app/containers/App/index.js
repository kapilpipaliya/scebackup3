/**
 *
 * App.js
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 *
 * NOTE: while this component should technically be a stateless functional
 * component (SFC), hot reloading does not currently support SFCs. If hot
 * reloading is not a necessity for you then you can refactor it and remove
 * the linting exception.
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import classNames from 'classnames';
import Drawer from 'material-ui/Drawer';
import List from 'material-ui/List';
import Divider from 'material-ui/Divider';
import IconButton from 'material-ui/IconButton';
import ChevronLeftIcon from 'material-ui-icons/ChevronLeft';
import { blue } from 'material-ui/colors';

import '../../assets/stylesheets/css/App.css';
import routes from '../../routes';
import SideBarList from '../../../app/components/sidebarlist';

import FlashMessage from '../../components/FlashMessage';
import Header from './Header';
// import withCurrentUser from "../../queries/users/currentUserQuery";

const blue600 = blue[600];
const white = blue[50];
const drawerWidth = 200;

const styles = (theme) => ({
  root: {
    width: '100%',
    // height: 430,
    marginTop: theme.spacing.unit * 3,
    zIndex: 1,
    // overflow: 'hidden',
  },
  appFrame: {
    position: 'relative',
    display: 'flex',
    width: '100%',
    height: '100%',
  },

  menuButton: {
    marginLeft: 12,
    marginRight: 20,
  },
  hide: {
    display: 'none',
  },
  drawerPaper: {
    position: 'relative',
    height: '100%',
    width: drawerWidth,
  },
  drawerHeader: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: '0 8px',
    ...theme.mixins.toolbar,
  },
  content: {
    width: '100%',
    marginLeft: -drawerWidth,
    flexGrow: 1,
    backgroundColor: theme.palette.background.default,
    padding: theme.spacing.unit * 3,
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    height: 'calc(100% - 56px)',
    marginTop: 56,
    [theme.breakpoints.up('sm')]: {
      content: {
        height: 'calc(100% - 64px)',
        marginTop: 64,
      },
    },
  },
  contentShift: {
    marginLeft: 0,
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },

  logo: {
    cursor: 'pointer',
    fontSize: 22,
    // color: props.textFullWhite,
    lineHeight: `${theme.spacing.desktopKeylineIncrement}px`,
    fontWeight: theme.typography.fontWeightLight,
    backgroundColor: blue600,
    paddingLeft: 40,
    height: 56,
  },
  menuItem: {
    color: white,
    fontSize: 14,
  },
  avatar: {
    div: {
      padding: '15px 0 20px 15px',
      // eslint-disable-next-line
      backgroundImage: `url(${require('../../images/material_bg.png')})`,
      height: 45,
    },
    icon: {
      float: 'left',
      display: 'block',
      marginRight: 15,
      boxShadow: '0px 0px 0px 8px rgba(0,0,0,0.2)',
    },
    span: {
      paddingTop: 12,
      display: 'block',
      color: 'white',
      fontWeight: 300,
      textShadow: '1px 1px #444',
    },
  },
});

class PersistentDrawer extends Component {
  state = {
    open: false,
  };

  handleDrawerOpen = () => {
    // this.setState({ open: true });
    this.setState({ open: !this.state.open });
  };

  handleDrawerClose = () => {
    // this.setState({ open: false });
    this.setState({ open: !this.state.open });
  };
  // componentWillReceiveProps(nextProps) {
  //   if (this.props.width !== nextProps.width) {
  //     this.setState({ navDrawerOpen: nextProps.width === 'sm' });
  //   }
  // }

  // componentDidMount() {
  //   const that = this;
  //
  //   Backend.getUsers().then(
  //     (response) => {
  //       that.setState({ friends: response.data });
  //     },
  //     (error) => {
  //       console.log(error);
  //     }
  //   );
  //
  //   // Try to load user next
  //   Facebook.IsLoggedIn().then(
  //     (response) => {
  //       // console.log("Facebook Response", response);
  //       that.setToken(response);
  //
  //       // console.log("loading feed")
  //       Facebook.Me().then(
  //         (response) => {
  //           // console.log('Feed response', response);
  //           that.setUser(response);
  //         },
  //         (err) => {
  //           console.log('feed error', err);
  //         }
  //       );
  //     },
  //     (error) => {
  //       console.log(error);
  //     }
  //   );
  // }
  //
  // setUser(user) {
  //   this.setState({
  //     user: {
  //       picture: user.picture.data.url,
  //       first_name: user.first_name,
  //       last_name: user.last_name,
  //       name: user.first_name,
  //       gender: user.gender,
  //       age_range: user.age_range,
  //     },
  //   });
  // }
  //
  // setToken(token) {
  //   this.setState({ token: token.accessToken, uid: token.uid });
  // }
  //
  //
  // login() {
  //   const that = this;
  //   Facebook.Login().then(
  //     (response) => {
  //       console.log('Login response', response);
  //       this.setToken(response);
  //
  //       Facebook.Me().then(
  //         (response) => {
  //           that.setUser(response);
  //         },
  //         (err) => {
  //           console.log('Facebook Profile Error', err);
  //         }
  //       );
  //     },
  //     (err) => {
  //       console.log('Facebook Login Error', err);
  //     }
  //   );
  // }
  //
  // logout() {
  //   // console.log("App.logout()")
  //   Facebook.Logout().then(
  //     (response) => {
  //       console.log(response);
  //     },
  //     (err) => {
  //       console.log(err);
  //     }
  //   );
  // }


  render() {
    // console.log(this.state) // Drawer Open even if state is false..
    const { classes } = this.props;
    return (
      <div className={classes.root}>
        <div className={classes.appFrame}>
          <Header
            open={this.state.open}
            handleChangeRequestNavDrawer={this.handleDrawerOpen}
          />

          <Drawer
            type="persistent"
            classes={{
              paper: classes.drawerPaper,
            }}
            open={this.state.open}
          >
            <div className={classes.drawerInner}>
              <div className={classes.drawerHeader}>
                <IconButton onClick={this.handleDrawerClose}>
                  <ChevronLeftIcon />
                </IconButton>
              </div>
              <div style={styles.logo}>
                Material Admin
              </div>
              <Divider />
              <SideBarList />
              <Divider />
              <List className={classes.list}>
                {/* {otherMailFolderListItems} */}
              </List>
            </div>
          </Drawer>

          <main
            className={classNames(
              classes.content,
              this.state.open && classes.contentShift
            )}
          >
            {/* <Header currentUser={currentUser} currentUserLoading={currentUserLoading} /> */}
            {/* <Header  /> */}
            <FlashMessage />

            {routes}

            {this.props.children}
          </main>
        </div>
      </div>
    );
  }
}

PersistentDrawer.propTypes = {
  children: PropTypes.element,
  // width: PropTypes.number,
};

const P = withStyles(styles)(PersistentDrawer);
// export default withCurrentUser(PersistentDrawer);
export default P;


// <div style={styles.avatar.div}>
//  {this.props.user ?
//    <Avatar
//      src={this.props.user.picture}
//      size={50}
//      style={styles.avatar.icon}
//    />
//    : <Avatar
//      icon={<Person/>}
//      size={50}
//      style={styles.avatar.icon}
//    />
//  }
//  <span style={styles.avatar.span}>{this.props.user ? this.props.user.name : 'Guest'}</span>
// </div>


// header props
// {/*styles={styles.header}*/}
// {/*// user={this.state.user}*/}
// {/*// onLogin={this.login.bind(this)}*/}
// {/*// onLogout={this.logout.bind(this)}*/}
