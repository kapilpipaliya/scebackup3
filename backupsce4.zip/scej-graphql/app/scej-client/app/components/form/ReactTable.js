import React, { Component } from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
export default class RTable extends Component {
  render() {
    return (
      <ReactTable
        defaultFiltered={[
          {
            id: '_destroy',
            value: false,
          },
        ]}
        defaultFilterMethod={(filter, row) =>
          (row[filter.id] === filter.value)}
        {...this.props}
      />
    );
  }
}
