import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import AccountForm from './_AccountForm';
import withAccountForEditing from '../../../queries/user/accounts/accountForEditingQuery';
import withUpdateAccount from '../../../mutations/user/accounts/updateAccountMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditAccount extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { account, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing account</h1>
        <AccountForm action={this.props.updateAccount} initialValues={{ ...flatIDValue(account) }} submitName="Update Account" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withAccountForEditing(withUpdateAccount(EditAccount));
