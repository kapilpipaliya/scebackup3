import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  orderType: gql`
    fragment OrderTypeFragment on SaleOrderType {
      id
      position
      slug
      order_type
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_ORDER_TYPE = gql`
    query getOrderType($id: ID) {
      orderType(id: $id) {
        ...OrderTypeFragment
      }
    }
    ${fragments.orderType}
  `;

  const withOrderType = graphql(GET_ORDER_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withOrderType(WrappedComponent);
}
