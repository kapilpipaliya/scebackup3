class CreateMfgMfgTxns < ActiveRecord::Migration[5.1]
  def change
    create_table :mfg_mfg_txns do |t|
      t.integer :position
      t.datetime :mfg_date, null: false
      t.references :mfg_casting, foreign_key: true
      t.references :sale_job, foreign_key: true, null: false
      t.references :material_location, foreign_key: true, null: false
      #t.references :mfg_department, foreign_key: true, null: false
      t.string :department
      t.references :user_account, foreign_key: true, null: false
      t.text :description
      t.decimal :issue_weight, null: false, precision: 10, scale: 3, :default => 0.0
      t.boolean :is_customer_stock, null: false, default:false
      t.integer :diamond_pcs, :default => 0
      t.decimal :diamond_weight, precision: 10, scale: 3, :default => 0.0
      t.integer :cs_pcs, :default => 0
      t.decimal :cs_weight, precision: 10, scale: 3, :default => 0.0
      t.decimal :t_issue, precision: 10, scale: 3, :default => 0.0
      t.decimal :t_issue_pure, precision: 10, scale: 3, :default => 0.0
      t.decimal :receive_weight, null: false, precision: 10, scale: 3, :default => 0.0
      t.decimal :receive_pure_weight, null: false, precision: 10, scale: 3, :default => 0.0
      t.decimal :final_receive_wt, null: false, precision: 10, scale: 3, :default => 0.0
      t.boolean :received, null: false, default:false
      t.decimal :final_receive_pure_wt, null: false, precision: 10, scale: 3, :default => 0.0
      t.decimal :dust_weight, precision: 10, scale: 3, :default => 0.0
      t.decimal :loss, precision: 10, scale: 3, :default => 0.0
      t.decimal :loss_pure, precision: 10, scale: 3, :default => 0.0

      t.timestamps
    end
    add_index :mfg_mfg_txns, :position
  end
end
