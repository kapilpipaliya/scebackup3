class CreateUserTaxTypes < ActiveRecord::Migration[5.1]
  def change
    create_table :user_tax_types do |t|
      t.integer :position
      t.string :slug

      t.timestamps
    end
    add_index :user_tax_types, :position
    add_index :user_tax_types, :slug, unique: true
  end
end
