import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withTaxType from '../../../queries/user/tax_types/taxTypeQuery';

class TaxType extends Component {
  render() {
    const { taxType, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="taxType">
        <p>TaxType</p>
        <h2 className="taxType-heading">{taxType.slug}</h2>
        <div className="taxType-meta">
          <span className="taxType-author">
            Posted by: <em>{/* {taxType.author.name} */}</em>
          </span>
          <span className="taxType-date">
            {moment(new Date(taxType.created_at)).fromNow()}
          </span>
        </div>
        <div className="taxType-content">
          contents display here: ID : {taxType.id}
        </div>
      </article>
    );
  }
}

export default withTaxType(TaxType);
