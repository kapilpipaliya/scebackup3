import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  country: gql`
    fragment CountryForEditingFragment on UserCountry {
      id
      position
      slug
      country
    }
  `,
};

export default function (WrappedComponent) {
  const GET_COUNTRY = gql`
    query getCountry($id: ID) {
      country(id: $id) {
        ...CountryForEditingFragment
      }
    }
    ${fragments.country}
  `;

  const withCountryForEditing = graphql(GET_COUNTRY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withCountryForEditing(WrappedComponent);
}
