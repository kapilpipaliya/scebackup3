require_relative 'boot'

require 'rails/all'

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module ScejGraphql
  class Application < Rails::Application
    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 5.1

    # Settings in config/environments/* take precedence over those specified here.
    # Application configuration should go into files in config/initializers
    # -- all .rb files in that directory are automatically loaded.

    # the sorting effect on speed of booting.
    config.autoload_paths << Rails.root.join('app/graphql')
    config.autoload_paths << Rails.root.join('app/graphql/types')
    config.autoload_paths << Rails.root.join('app/graphql/utils')
    config.autoload_paths << Rails.root.join('app/graphql/mutations')
    config.autoload_paths << Rails.root.join('app/graphql/interfaces')
    config.autoload_paths << Rails.root.join('app/graphql/mutations/design')
    config.autoload_paths << Rails.root.join('app/graphql/mutations/material')
    config.autoload_paths << Rails.root.join('app/graphql/mutations/mfg')
    config.autoload_paths << Rails.root.join('app/graphql/mutations/sale')
    config.autoload_paths << Rails.root.join('app/graphql/mutations/user')


    config.middleware.insert_before 0, Rack::Cors do
      allow do
        # origins 'localhost:3000'
        # resource '*', headers: :any, credentials: true, methods: [:get, :post, :put, :patch, :delete, :head, :options], expose: ['X-Requested-With', 'Content-Type', 'Accept']
        origins '*'
        resource '*', :headers => :any, :methods => [:get, :post, :options]
      end
    end
  end
end
