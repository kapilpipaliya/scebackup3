export default (process.env.NODE_ENV === 'development'
  ? 'https://onwin2-kapilp.c9users.io:8081'
  : '');
