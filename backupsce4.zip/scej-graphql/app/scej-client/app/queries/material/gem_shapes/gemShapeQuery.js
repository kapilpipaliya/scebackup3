import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  gemShape: gql`
    fragment GemShapeFragment on MaterialGemShape {
      id
      material_id { id slug }
      position
      slug
      shape
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_GEM_SHAPE = gql`
    query getGemShape($id: ID) {
      gemShape(id: $id) {
        ...GemShapeFragment
      }
    }
    ${fragments.gemShape}
  `;

  const withGemShape = graphql(GET_GEM_SHAPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withGemShape(WrappedComponent);
}
