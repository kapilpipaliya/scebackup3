import React, { Component } from 'react';
import Button from 'material-ui/Button';
import RoleForm from './_RoleForm';
import withCreateRole from '../../../mutations/user/roles/createRoleMutation';

class NewRole extends Component {
  render() {
    return (
      <div>
        <h1>New Role</h1>
        <RoleForm action={this.props.createRole} submitName="Create Role" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateRole(NewRole);
