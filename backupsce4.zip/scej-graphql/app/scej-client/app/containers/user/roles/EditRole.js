import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import RoleForm from './_RoleForm';
import withRoleForEditing from '../../../queries/user/roles/roleForEditingQuery';
import withUpdateRole from '../../../mutations/user/roles/updateRoleMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditRole extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { role, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing role</h1>
        <RoleForm action={this.props.updateRole} initialValues={{ ...flatIDValue(role) }} submitName="Update Role" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withRoleForEditing(withUpdateRole(EditRole));
