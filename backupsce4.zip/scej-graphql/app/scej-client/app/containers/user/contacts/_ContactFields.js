import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI } from '../../../utils/libs';

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Slug extends React.Component {
  render() {
    return (
      <Field name='slug' label='Code' component={F} {...this.props} />
    );
  }
}

export class FirstName extends React.Component {
  render() {
    return (
      <Field name='first_name' label='First name' component={F} {...this.props} />
    );
  }
}

export class LastName extends React.Component {
  render() {
    return (
      <Field name='last_name' label='Last name' component={F} {...this.props} />
    );
  }
}

export class Email extends React.Component {
  render() {
    return (
      <Field name='email' label='Email' component={F} {...this.props} />
    );
  }
}

export class Phone extends React.Component {
  render() {
    return (
      <Field name='phone' label='Phone' component={F} {...this.props} />
    );
  }
}

export class Mobile extends React.Component {
  render() {
    return (
      <Field name='mobile' label='Mobile' component={F} {...this.props} />
    );
  }
}

export class Salary extends React.Component {
  render() {
    return (
      <Field name='salary' label='Salary' component={F} parse={pI} placeholder='Salary' type='number' {...this.props} />
    );
  }
}

// import { Position, Slug, FirstName, LastName, Email, Phone, Mobile, Salary } from './_ContactFields'; // eslint-disable-line no-unused-vars
