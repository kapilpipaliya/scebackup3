class CreateSaleJobViews < ActiveRecord::Migration[5.1]
  def up
    self.connection.execute %Q( CREATE VIEW public.sale_job_views
      AS
      SELECT
        sale_orders.id AS id01,
        (
          (sale_orders."position" || '/'::text) || sale_jobs."position"
        ) AS "position",
        sale_orders."position" AS position_order,
        sale_orders.customer_id,
        sale_orders.taken_by_id,
        sale_orders.order_date,
        sale_orders.delivery_date,
        sale_orders.mfg_product_type_id,
        sale_orders.description,
        sale_orders.created_at,
        sale_orders.updated_at,
        sale_jobs.id,
        sale_jobs.processable_type,
        sale_jobs.processable_id,
        sale_jobs.is_exist,
        sale_jobs."position" AS position_job,
        sale_jobs.design_style_id,
        sale_jobs.mfg_product_type_id AS mfg_product_type_id01,
        sale_jobs.material_location_id,
        sale_jobs.material_material_id,
        sale_jobs.metal_purity_id,
        sale_jobs.metal_color_id,
        sale_jobs.qty,
        sale_jobs.diamond_clarity_id,
        sale_jobs.diamond_color_id,
        sale_jobs.cs_clarity_id,
        sale_jobs.cs_color_id,
        sale_jobs."instruction" AS instruction,
        sale_jobs."item_size" AS item_size,
        sale_jobs.mfg_priority_id,
        sale_jobs.mfg_department_id,
        sale_jobs.net_weight,
        sale_jobs.pure_weight,
        sale_jobs.diamond_pcs,
        sale_jobs.diamond_weight,
        sale_jobs.cs_pcs,
        sale_jobs.cs_weight,
        sale_jobs.gross_weight,
        sale_jobs.created_at AS created_at01,
        sale_jobs.updated_at AS updated_at01
      FROM sale_orders, sale_jobs
      WHERE
        (sale_orders.id = sale_jobs.processable_id);
        )
  end

  def down
    self.connection.execute "DROP VIEW IF EXISTS public.sale_job_views;"
  end
end