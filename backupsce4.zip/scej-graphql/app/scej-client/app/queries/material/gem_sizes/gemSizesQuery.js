import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  gemSize: gql`
    fragment GemSizePreviewFragment on MaterialGemSize {
      id
      material_id { id slug }
      gem_shape_id { id slug }
      position
      slug
      mm_size
      carat_weight
      price
      created_at
    }
  `,
};

export const AllGemSizesQuery = gql`
  query allMaterialGemSizesQuery($f_material_id: Int, $f_gem_shape_id: Int, $f_gem_clarity_id: Int) {
    gemSizesCount
    allMaterialGemSizes(f_material_id: $f_material_id, f_gem_shape_id: $f_gem_shape_id, f_gem_clarity_id: $f_gem_clarity_id) {
      ...GemSizePreviewFragment
    }
  }
  ${fragments.gemSize}
`;

export default graphql(AllGemSizesQuery, {
  name: 'gemsizes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_material_id: 0, f_gem_shape_id: 0, f_gem_clarity_id: 0 },
  }),
});
