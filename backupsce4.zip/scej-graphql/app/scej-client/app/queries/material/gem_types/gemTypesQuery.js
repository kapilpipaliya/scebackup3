import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  gemType: gql`
    fragment GemTypePreviewFragment on MaterialGemType {
      id
      position
      slug
      gem_type
      isdefault
      created_at
    }
  `,
};

export const AllGemTypesQuery = gql`
  query allMaterialGemTypesQuery {
    gemTypesCount
    allMaterialGemTypes {
      ...GemTypePreviewFragment
    }
  }
  ${fragments.gemType}
`;

export default graphql(AllGemTypesQuery, {
  name: 'gemtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
