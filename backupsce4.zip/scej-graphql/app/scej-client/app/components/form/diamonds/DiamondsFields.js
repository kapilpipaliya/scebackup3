import React from 'react';
import { Field } from 'redux-form/immutable';

import I from '../RenderInput';
import D from '../RenderNumber';
import S from '../SimpleSelect';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI, parsefloat as pF } from '../../../utils/libs';

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' component={I} parse={pI} type='number' {...this.props} />
    );
  }
}

export class MaterialId extends React.Component {
  render() {
    return (
      <Field name='material_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class GemShapeId extends React.Component {
  render() {
    return (
      <Field name='gem_shape_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class GemClarityId extends React.Component {
  render() {
    return (
      <Field name='gem_clarity_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class ColorId extends React.Component {
  render() {
    return (
      <Field name='color_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class GemSizeId extends React.Component {
  render() {
    return (
      <Field name='gem_size_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Pcs extends React.Component {
  render() {
    return (
      <Field name='pcs' component={I} parse={pI} type='number' {...this.props} />
    );
  }
}

export class Pointer extends React.Component {
  render() {
    return (
      <Field name='pointer' component={D} parse={pF} {...this.props} />
    );
  }
}

export class Weight extends React.Component {
  render() {
    return (
      <Field name='weight' component={D} parse={pF} {...this.props} />
    );
  }
}

// import { Position, MaterialId, GemShapeId, GemClarityId, ColorId, GemSizeId, Pcs, Pointer, Weight } from './DiamondsFields'; // eslint-disable-line no-unused-vars
