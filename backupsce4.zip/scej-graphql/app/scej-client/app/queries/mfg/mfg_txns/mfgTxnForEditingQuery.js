import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  mfgTxn: gql`
    fragment MfgTxnForEditingFragment on MfgMfgTxn {
      id
      position
      mfg_date
      casting_id { id slug }
      job_id { id slug }
      location_id { id slug }
      department
      entry_by_id { id slug }
      description
      issue_weight
      is_customer_stock
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      t_issue
      t_issue_pure
      receive_weight
      receive_pure_weight
      final_receive_wt
      received
      final_receive_pure_wt
      dust_weight
      loss
      loss_pure
    }
  `,
};

export default function (WrappedComponent) {
  const GET_MFG_TXN = gql`
    query getMfgTxn($id: ID) {
      mfgTxn(id: $id) {
        ...MfgTxnForEditingFragment
      }
    }
    ${fragments.mfgTxn}
  `;

  const withMfgTxnForEditing = graphql(GET_MFG_TXN, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMfgTxnForEditing(WrappedComponent);
}
