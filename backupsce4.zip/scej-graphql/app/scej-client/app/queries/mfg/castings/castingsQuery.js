import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  casting: gql`
    fragment CastingPreviewFragment on MfgCasting {
      id
      position
      date
      slug
      employee_id { id slug }
      description
      t_issue
      t_issue_pure
      t_rcv
      t_rcv_pure
      loss
      loss_pure
      created_at
    }
  `,
};

export const AllCastingsQuery = gql`
  query allMfgCastingsQuery {
    castingsCount
    allMfgCastings {
      ...CastingPreviewFragment
    }
  }
  ${fragments.casting}
`;

export default graphql(AllCastingsQuery, {
  name: 'castings',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
