// import CloseIcon from 'material-ui-icons/Close';
// import Snackbar from 'material-ui/Snackbar';
// import { withStyles } from 'material-ui/styles';

// const stylesJob = (theme) => ({
//   close: {
//     width: theme.spacing.unit * 4,
//     height: theme.spacing.unit * 4,
//   },
// });

// <Snackbar
//   anchorOrigin={{
//     vertical: 'bottom',
//     horizontal: 'left',
//   }}
//   open={this.state.open_snackbar}
//   autoHideDuration={6000}
//   onRequestClose={this.handleRequestCloseSnackbar}
//   SnackbarContentProps={{
//     'aria-describedby': 'message-id',
//   }}
//   message={<span id="message-id">Note archived</span>}
//   action={[
//     <Button key="undo" color="accent" dense onClick={this.handleRequestCloseSnackbar}>
//       UNDO
//     </Button>,
//     <IconButton
//       key="close"
//       aria-label="Close"
//       color="inherit"
//       className={classes.close}
//       onClick={this.handleRequestCloseSnackbar}
//     >
//       <CloseIcon />
//     </IconButton>,
//   ]}
// />
