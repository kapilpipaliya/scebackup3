import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  rateOn: gql`
    fragment RateOnFragment on MaterialRateOn {
      id
      material_type_id { id slug }
      position
      slug
      rateon
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_RATE_ON = gql`
    query getRateOn($id: ID) {
      rateOn(id: $id) {
        ...RateOnFragment
      }
    }
    ${fragments.rateOn}
  `;

  const withRateOn = graphql(GET_RATE_ON, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withRateOn(WrappedComponent);
}
