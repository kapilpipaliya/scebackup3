
import validatorjs from 'validatorjs';

export default {
  plugins: { dvr: validatorjs },
  options: {
  },
  fields: [
  "position",
  "country_id",
  "slug",
  "state"
],
  initials: {
},
  labels: {
  "position": "SN#",
  "country_id": "Country",
  "slug": "Code",
  "state": "State"
},
  placeholders: {
  "position": "Position",
  "country_id": "Country",
  "slug": "Slug",
  "state": "State"
},
  types: {
  "position": "number",
  "country_id": "number",
  "slug": "text",
  "state": "text"
},
  rules: {
  "position": "",
  "country_id": "",
  "slug": "",
  "state": ""
},
  hooks: {
    onSuccess(form) {
      alert('Form is valid! Send the request here.');
      // get field values
      console.log('Form Values!', form.values());
    },
    onError(form) {
      alert('Form has errors!');
      // get all form errors
      console.log('All form errors', form.errors());
    }
  },
  bindings: {
}
}
