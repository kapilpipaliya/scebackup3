import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import TextField from 'material-ui/TextField';
import capitalize from '../../utils/stringEnhancer';

const styles = (theme) => ({
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    // width: 200,
  },
});

class RenderField extends Component {
  static propTypes = {
    input: PropTypes.object.isRequired,
    meta: PropTypes.object.isRequired,
    type: PropTypes.string,
    rows: PropTypes.number,
    placeholder: PropTypes.string,
    label: PropTypes.string,
    initialValue: PropTypes.object,
    hint: PropTypes.string,
    onChange2: PropTypes.func,
  };

  static defaultProps = {
    // type: 'text',
    rows: 6,
    placeholder: '',
    label: '',
  };

  constructor(props) {
    super(props);
    const { label, input: { name } } = this.props;
    this.state = { label: label || capitalize(name) };
    this.input = this.input.bind(this);
  }

  input() {
    const {
      meta: { touched, error, invalid },
      input,
      input: { name },
      type,
      rows,
      placeholder,
      onChange2,
      ...custom // This is Proper Format for Custom properties in this.props. It includes not included properties.!!
    } = this.props;
    if (custom) {
      custom.classes = undefined;
    } // This Key Making Problems.
    // eslint-disable-next-line
    const { classes } = this.props;

    const inputChange = (e) => {
      input.onChange(e);
      if (onChange2) {
        onChange2(e.target.value);
      }
    };

    if (type === 'textarea') {
      return (
        <TextField
          error={touched && invalid}
          rows={rows}
          id={name}
          label={this.state.label}
          placeholder={placeholder}
          helperText={touched && error}
          multiline
          // {...input}
          name={input.name}
          onBlur={input.onBlur}
          // onChange= {input.onChange}
          onDragStart={input.onDragStart}
          onDrop={input.onDrop}
          onFocus={input.onFocus}
          value={input.value}
          onChange={inputChange}
          {...custom}
          fullWidth
        />
      );
    }
    return (
      <TextField
        error={touched && invalid}
        type={type}
        id={name}
        label={this.state.label}
        placeholder={placeholder}
        helperText={touched && error}
        // {...input}
        name={input.name}
        onBlur={input.onBlur}
        // onChange= {input.onChange}
        onDragStart={input.onDragStart}
        onDrop={input.onDrop}
        onFocus={input.onFocus}
        value={input.value}
        onChange={inputChange}
        {...custom}
        fullWidth
      />
    );
  }

  render() {
    return (this.input());
  }
}

export default withStyles(styles)(RenderField);
