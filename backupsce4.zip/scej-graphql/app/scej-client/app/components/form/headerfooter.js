import React, { Component } from 'react';
import { Sum, Count } from '../../utils/libs';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
export class Footer extends Component {
  render() {
    return (
      <span><strong>Sum:</strong>{Sum(this.props.data, this.props.filterColumn, this.props.precision)}</span>
    );
  }
}
export class FooterCount extends Component {
  render() {
    return (
      <span><strong>Count:</strong>{Count(this.props.data)}</span>
    );
  }
}
