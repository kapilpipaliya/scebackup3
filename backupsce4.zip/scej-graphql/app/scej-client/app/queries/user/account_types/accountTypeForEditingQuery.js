import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  accountType: gql`
    fragment AccountTypeForEditingFragment on UserAccountType {
      id
      position
      slug
      account_type
    }
  `,
};

export default function (WrappedComponent) {
  const GET_ACCOUNT_TYPE = gql`
    query getAccountType($id: ID) {
      accountType(id: $id) {
        ...AccountTypeForEditingFragment
      }
    }
    ${fragments.accountType}
  `;

  const withAccountTypeForEditing = graphql(GET_ACCOUNT_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withAccountTypeForEditing(WrappedComponent);
}
