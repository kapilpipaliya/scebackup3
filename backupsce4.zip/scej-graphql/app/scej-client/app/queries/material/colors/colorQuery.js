import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  color: gql`
    fragment ColorFragment on MaterialColor {
      id
      material_id { id slug }
      position
      slug
      color
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_COLOR = gql`
    query getColor($id: ID) {
      color(id: $id) {
        ...ColorFragment
      }
    }
    ${fragments.color}
  `;

  const withColor = graphql(GET_COLOR, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withColor(WrappedComponent);
}
