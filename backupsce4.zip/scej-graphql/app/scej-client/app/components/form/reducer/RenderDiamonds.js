/*
import React, { Component } from 'react';
import { Field } from 'redux-form/immutable';
// Redux
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withApollo } from 'react-apollo';
// Material-Ui
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
import IconButton from 'material-ui/IconButton';
import DeleteIcon from 'material-ui-icons/Delete';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';

import RenderInput from './../RenderInput';
import SimpleSelect from '../../../components/form/SimpleSelect';
import * as actions from './../reducer/actions_diamonds';
import { parseint as pI, parsefloat as pF } from '../../../utils/libs';
const styles = (theme) => ({});

class RenderDiamonds extends Component {
  render() {
    const { fields, meta: { touched, error, submitFailed }, change } = this.props;
    const {
      materials, gemshapes, gemclarities, gemsizes, colors,
    } = this.props;

    const data = this.props.diamonds;

    const columns = [
      // @formatter:off
      {
        Header: '',
        Cell: (props) =>
          (<div>
            <span>#{props.index}</span>
            <IconButton
              color="accent"
              aria-label="Delete"
              onClick={() => {
                fields.remove(props.index);
                this.props.calcTotals();
              }}
            >
              <DeleteIcon />
            </IconButton>
           </div>),
      },
      { Header: 'Position', Cell: (props) => <Field name={`${fields.name}[${props.index}].position`} component={RenderInput} parse={pI} type="number" /> },
      { Header: 'Material', Cell: (props) => <Field name={`${fields.name}[${props.index}].material_id`} component={SimpleSelect} parse={pI} options={materials[props.index]} onChange2={(value) => this.props.actions.fetchMaterialChange(this.props.client, value, props.index)} /> },
      { Header: 'Shape', Cell: (props) => <Field name={`${fields.name}[${props.index}].gem_shape_id`} component={SimpleSelect} parse={pI} options={gemshapes[props.index]} onChange2={(gem_shape_id) => this.props.actions.fetchShapeOrClarityChange(this.props.client, this.props.diamonds[props.index].material_id, gem_shape_id, this.props.diamonds[props.index].gem_clarity_id, props.index)} /> },
      { Header: 'Clarity', Cell: (props) => <Field name={`${fields.name}[${props.index}].gem_clarity_id`} component={SimpleSelect} parse={pI} options={gemclarities[props.index]} onChange2={(gem_clarity_id) => this.props.actions.fetchShapeOrClarityChange(this.props.client, this.props.diamonds[props.index].material_id, this.props.diamonds[props.index].gem_shape_id, gem_clarity_id, props.index)} /> },
      { Header: 'Color', Cell: (props) => <Field name={`${fields.name}[${props.index}].color_id`} component={SimpleSelect} parse={pI} options={colors[props.index]} /> },
      {
        Header: 'Size',
        Cell: (props) => (<Field
          name={`${fields.name}[${props.index}].gem_size_id`}
          component={SimpleSelect}
          parse={pI}
          options={gemsizes[props.index]}
          onChange2={(weight) => {
            const pointer = gemsizes[props.index][weight].carat_weight;
            this.props.change(`${fields.name}[${props.index}].pointer`, pointer);
            this.props.change(`${fields.name}[${props.index}].weight`, this.props.diamonds[props.index].pcs * pointer);
            this.props.calcTotals();
          }}
        />),
      },
      {
        Header: 'Pcs',
        Cell: (props) => (<Field
          name={`${fields.name}[${props.index}].pcs`}
          component={RenderInput}
          parse={pI}
          onChange2={(pcs) => {
            this.props.change(`${fields.name}[${props.index}].weight`, pcs * this.props.diamonds[props.index].pointer);
            this.props.calcTotals();
          }}
        />),
      },
      {
        Header: 'Pointer',
        Cell: (props) => (<Field
          name={`${fields.name}[${props.index}].pointer`}
          component={RenderInput}
          parse={pF}
          disabled
          onChange2={
            (pointer) => this.props.change(`${fields.name}[${props.index}].weight`, this.props.diamonds[props.index].pcs * pointer)
          }
        />),
      },
      { Header: 'Weight(Ct)', Cell: (props) => <Field name={`${fields.name}[${props.index}].weight`} component={RenderInput} parse={pF} disabled /> },
      // @formatter:on
    ];

    return (
      <div>
        <h2>Diamonds:</h2>
        {/!* <Button onClick={()=>this.props.materials.refetch({f_m_type: 1})}> M Type Metal </Button> *!/}
        {/!* <Button onClick={()=>this.props.materials.refetch({f_m_type: 2})}> M Type Gem </Button> *!/}
        <Button
          raised
          color="primary"
          type="button"
          onClick={() => {
            fields.push({});
            this.props.actions.diamondsFetchMaterials(this.props.client, 2, fields.length);
            this.props.actions.fetchMaterialChange(this.props.client, 2, fields.length);
            // this.fexecuteM(this.props.client, 2, fields.length); // Fetch Materials.
            // this.fexecuteMChange(fields.length, 4) // Fetch Shape, Clarity, Color.
          }
          }
        >
          Add Diamond
        </Button>
        {(touched || submitFailed) && error && <span>{error}</span>}
        <ReactTable
          data={data}
          columns={columns}
          defaultPageSize={10}
        />
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  materials: state.diamonds.materials,
  gemshapes: state.diamonds.gemshapes,
  gemclarities: state.diamonds.gemclarities,
  gemsizes: state.diamonds.gemsizes,
  colors: state.diamonds.colors,
});
const mapDispatchToProps = (dispatch, ownProps) => ({
  actions: bindActionCreators({ ...actions }, dispatch),
});


RenderDiamonds = connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(withApollo(RenderDiamonds)));

export default withApollo(RenderDiamonds);


/!* You can also use this method to dispatch change.
RenderDiamonds = connect(null,
  /!* mapDispatchToProps = * function(dispatch) {
    return {
      // This will be passed as a property to the presentational component
      changeFieldValue: function (field, value) {
        dispatch(change(form, field, value))
      }
    }
  }
)
*!/
// ReactJs
// <efdee>: yourarray.map(item => { ...item, weight: item.pcs*item.pointer });
// <efdee>: yourarray.map(item => ({ ...item, weight: item.pcs*item.pointer })); rather

// Javascript:
// <joeytwiddle> array.forEach(obj => { obj.weight = obj.pcs * obj.pointer; });
*/
