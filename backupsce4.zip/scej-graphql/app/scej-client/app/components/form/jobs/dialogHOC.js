import React from 'react';
import { withStyles } from 'material-ui/styles';
// import Button from 'material-ui/Button';
// import Icon from 'material-ui/Icon';
// import Snackbar from 'material-ui/Snackbar';
// import IconButton from 'material-ui/IconButton';
// import CloseIcon from 'material-ui-icons/Close';
// import Typography from 'material-ui/Typography';
// import Dialog, { DialogActions, DialogContent, DialogContentText, DialogTitle } from 'material-ui/Dialog';
const stylesJob = (theme) => ({
  close: {
    width: theme.spacing.unit * 4,
    height: theme.spacing.unit * 4,
  },
});

const DialogHOC = (InnerComponent) => class extends React.Component {
  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
      />
    );
  }
};

export default withStyles(stylesJob)(DialogHOC);
