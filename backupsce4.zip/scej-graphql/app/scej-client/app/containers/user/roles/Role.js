import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withRole from '../../../queries/user/roles/roleQuery';

class Role extends Component {
  render() {
    const { role, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="role">
        <p>Role</p>
        <h2 className="role-heading">{role.slug}</h2>
        <div className="role-meta">
          <span className="role-author">
            Posted by: <em>{/* {role.author.name} */}</em>
          </span>
          <span className="role-date">
            {moment(new Date(role.created_at)).fromNow()}
          </span>
        </div>
        <div className="role-content">
          contents display here: ID : {role.id}
        </div>
      </article>
    );
  }
}

export default withRole(Role);
