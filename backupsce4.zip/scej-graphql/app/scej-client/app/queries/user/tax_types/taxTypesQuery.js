import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  taxType: gql`
    fragment TaxTypePreviewFragment on UserTaxType {
      id
      position
      slug
      created_at
    }
  `,
};

export const AllTaxTypesQuery = gql`
  query allUserTaxTypesQuery {
    taxTypesCount
    allUserTaxTypes {
      ...TaxTypePreviewFragment
    }
  }
  ${fragments.taxType}
`;

export default graphql(AllTaxTypesQuery, {
  name: 'taxtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
