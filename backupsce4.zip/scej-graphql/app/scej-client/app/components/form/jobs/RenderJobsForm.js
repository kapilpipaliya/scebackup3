import React, { Component } from 'react';
import _ from 'lodash';
import { fromJS } from 'immutable';
import { withApollo } from 'react-apollo';
import Button from 'material-ui/Button';
import Icon from 'material-ui/Icon';
import IconButton from 'material-ui/IconButton';
import Typography from 'material-ui/Typography';

// Be sure to include styles at some point, probably during your bootstrapping
import RSelect from 'react-select';
import 'react-select/dist/react-select.css';
import RTable from '../ReactTable';
import S2 from '../../shared/MySelect';
import { Footer, FooterCount } from '../headerfooter';
import { ProcessableType, ProcessableId, SalableType, SalableId, IsExist, Position, StyleId, ProductTypeId, LocationId, MaterialId, MetalPurityId, MetalColorId, Qty, DiamondClarityId, DiamondColorId, CsClarityId, CsColorId, Instruction, ItemSize, PriorityId, DepartmentId, NetWeight, PureWeight, DiamondPcs, DiamondWeight, CsPcs, CsWeight, GrossWeight } from './JobsFields'; // eslint-disable-line no-unused-vars

@withApollo
export default class RenderJobs extends Component {
  render() {
    const {
      fields, fields: { name }, meta: { touched, error, submitFailed }, diamondsPage,
    } = this.props;

    const data = this.props.jobs.toJS();

    const fName = (p) => (`${name}[${p.index}]`);
    // @formatter:off
    const tableHash = {
      0: { accessor: '_destroy', Header: '', Cell: (p) => previewCell(p) },
      1: { accessor: 'is_exist', Header: 'Final *', Cell: (p) => <IsExist name={`${fName(p)}.is_exist`} label="Final" onChange2={(v) => { this.checkboxToogle(p.index, v); }} /> },
      2: { Header: () => <div>Position<br /><Button onClick={() => this.autoPosition()}>Auto No</Button></div>, Footer: <FooterCount data={data} />, Cell: (p) => <Position name={`${fName(p)}.position`} disabled={!data[p.index].is_exist} /> },
      3: { Header: 'Style *', Cell: (p) => <StyleId name={`${fName(p)}.style_id`} options={this.props.o.jobStyles[p.index]} onChange2={(sId) => this.props.calcStyleChange(this.props.client, p.index, sId, `${this.props.fields.name}[${p.index}]`, this.props.change)} /> },
      4: { Header: 'Product Type', Cell: (p) => <ProductTypeId name={`${fName(p)}.product_type_id`} options={this.props.o.jobProductTypes[p.index]} /> },
      5: { Header: () => <div>Location<br /><S2 /></div>, Cell: (p) => <LocationId name={`${fName(p)}.location_id`} options={this.props.o.jobLocations[p.index]} /> },
      6: { Header: 'Material *', Cell: (p) => <MaterialId name={`${fName(p)}.material_id`} options={this.props.o.jobMaterials[p.index]} onChange2={(v) => this.materialChange(p.index, v)} /> },
      7: { Header: 'Purity *', Cell: (p) => <MetalPurityId name={`${fName(p)}.metal_purity_id`} options={this.props.o.jobMetalPurities[p.index]} onChange2={(v) => this.purityChange(p.index, v)} /> },
      8: { Header: 'Tone *', accessor: 'metal_color_id', Cell: (p) => <MetalColorId name={`${fName(p)}.metal_color_id`} options={this.props.o.jobColors[p.index]} /> },
      9: {
        Header: 'Qty *', Footer: <Footer data={data} filterColumn="qty" precision="0" />, accessor: 'qty', Cell: (p) => <Qty name={`${fName(p)}.qty`} onChange2={(q) => this.qtyChange(p.index, q)} />,
      },
      // TODO MAKE SELECT WORKING FOR D COLOR, CS PCS, CS WT.
      10: { Header: () => <div>D Clarity<br /><S2 /></div>, Cell: (p) => <DiamondClarityId name={`${fName(p)}.diamond_clarity_id`} options={this.props.o.jobDGemClarities[p.index]} /> },
      11: { Header: () => <div>D Color<br /><S2 /></div>, Cell: (p) => <DiamondColorId name={`${fName(p)}.diamond_color_id`} options={this.props.o.jobDColors[p.index]} /> },
      12: { Header: () => <div>CS Clarity<br /><S2 /></div>, Cell: (p) => <CsClarityId name={`${fName(p)}.cs_clarity_id`} options={this.props.o.jobCSGemClarities[p.index]} /> },
      13: { Header: () => <div>CS Color<br /><S2 /></div>, Cell: (p) => <CsColorId name={`${fName(p)}.cs_color_id`} options={this.props.o.jobCSColors[p.index]} /> },
      14: { Header: 'Instruction', Cell: (p) => <Instruction name={`${fName(p)}.instruction`} /> },
      15: { Header: 'Item Size', Cell: (p) => <ItemSize name={`${fName(p)}.item_size`} /> },
      16: { Header: 'Priority', Cell: (p) => <PriorityId name={`${fName(p)}.priority_id`} options={this.props.o.jobPriorities[p.index]} /> },
      17: { Header: 'Department', accessor: 'department_id', Cell: (p) => <DepartmentId name={`${fName(p)}.department_id`} options={this.props.o.jobDepartments[p.index]} /> },
      18: { Header: 'Net Wt(g)', Footer: <Footer data={data} filterColumn="net_weight" precision="3" />, Cell: (p) => <NetWeight name={`${fName(p)}.net_weight`} disabled /> },
      19: { Header: 'Pure Wt(g)', Footer: <Footer data={data} filterColumn="pure_weight" precision="3" />, Cell: (p) => <PureWeight name={`${fName(p)}.pure_weight`} disabled /> },
      20: { Header: 'D PCs', Footer: () => <span>Total: {this.props.totals.dPcs} </span>, Cell: (p) => <DiamondPcs name={`${fName(p)}.diamond_pcs`} disabled /> },
      21: { Header: 'D Wt(Ct)', Footer: () => <span>Total: {this.props.totals.dWt} </span>, Cell: (p) => <DiamondWeight name={`${fName(p)}.diamond_weight`} disabled /> },
      22: { Header: 'CS PCs', Footer: () => <span>Total: {this.props.totals.cSPcs} </span>, Cell: (p) => <CsPcs name={`${fName(p)}.cs_pcs`} disabled /> },
      23: { Header: 'CS Wt(Ct)', Footer: () => <span>Total: {this.props.totals.cSWt} </span>, Cell: (p) => <CsWeight name={`${fName(p)}.cs_weight`} disabled /> },
      24: { Header: 'Gross Wt(g)', Footer: () => <span>Total: {this.props.totals.grossWt} </span>, Cell: (p) => <GrossWeight name={`${fName(p)}.gross_weight`} disabled /> },
    // @formatter:on
    };
    const columns = _.map(tableHash, (v) => v);
    const previewCell = (p) => (
      <div>
        <Typography type="body2" align="center">
          <IconButton
            color="accent"
            aria-label="Delete"
            onClick={() => {
              // fields.remove(p.index)
              this.props.a.orderJobDeleteRow(p.index);
              fields.remove(p.index);
            }}
          >
            <Icon color="primary" style={{ fontSize: 25 }}>delete_forever</Icon>
          </IconButton>
          <IconButton color="primary" aria-label="Delete" onClick={() => diamondsPage(p.index)}>
            <Icon color="primary" style={{ fontSize: 25 }}>settings</Icon>
          </IconButton>
        </Typography>
      </div>
    );
    const options = [
      { value: 'one', label: 'One' },
      { value: 'two', label: 'Two' },
    ];
    return (
      <div>
        <span>TODO : MultiSelect select when selected it automatically add values to jobs row.</span>
        <RSelect
          name="form-field-name"
          value="one"
          options={options}
          // onChange={logChange}
          searchable
          multi
        />
        <Button
          raised
          color="primary"
          type="button"
          onClick={async () => {
            fields.push(fromJS({ _destroy: false }));
            const row = fields.length;
            this.props.a.orderFetchStyles(this.props.client, row);
            this.props.a.orderFetchMaterials(this.props.client, 1, row);
            this.props.a.orderFetchMetalPurities(this.props.client, 1, row);
            this.props.a.orderFetchColors(this.props.client, 1, row);
            this.props.a.orderFetchDColors(this.props.client, 4, row);
            this.props.a.orderFetchCSColors(this.props.client, 5, row);
            this.props.a.orderFetchDGemClarities(this.props.client, 4, row);
            this.props.a.orderFetchCSGemClarities(this.props.client, 5, row);
            this.props.a.orderFetchPriorities(this.props.client, row);
            this.props.a.orderFetchLocations(this.props.client, row);
            this.props.a.orderFetchProductTypes(this.props.client, row);
            this.props.a.orderFetchDepartments(this.props.client, row);
            this.props.change(`${this.props.fields.name}[${row}].qty`, 1);
            this.props.change(`${this.props.fields.name}[${row}].priority_id`, 2);
          }}
        >
          Add Job
        </Button>
        {(touched || submitFailed) && error && <span>{error}</span>}
        <RTable
          data={data}
          columns={columns}

          defaultPageSize={10}
          sortable={false}
          resizable={false}

          SubComponent={(row) => (
            <div style={{ padding: '20px' }}>
              { console.log(row) }
              <span> I worked</span>
            </div>)}
        />
      </div>
    );
  }
}
