import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  sale: gql`
    fragment SaleForEditingFragment on SaleSale {
      id
      position
      customer_id { id slug }
      sold_by_id { id slug }
      date
      due_date
      description
      net_weight
      pure_weight
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      tax
      discount
      amount
    }
  `,
};

export default function (WrappedComponent) {
  const GET_SALE = gql`
    query getSale($id: ID) {
      sale(id: $id) {
        ...SaleForEditingFragment
      }
    }
    ${fragments.sale}
  `;

  const withSaleForEditing = graphql(GET_SALE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withSaleForEditing(WrappedComponent);
}
