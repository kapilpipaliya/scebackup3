import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withAddressesData from '../../../queries/user/addresses/addressesQuery';

import ListAddresses from './_ListAddresses';
import HeadListAddresses from './_HeadListAddresses';

class AllAddresses extends Component {
  componentDidMount() {
    this.props.addresses.refetch(); // You can pass variables here.
  }

  render() {
    const { addresses: { loading, error }, addresses } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListAddresses />
        <ListAddresses data={addresses} />
      </div>
    );
  }
}

export default withAddressesData(AllAddresses);
