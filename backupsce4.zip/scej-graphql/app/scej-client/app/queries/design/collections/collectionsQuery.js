import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  collection: gql`
    fragment CollectionPreviewFragment on DesignCollection {
      id
      position
      slug
      collection
      parent_id { id slug }
      created_at
    }
  `,
};

export const AllCollectionsQuery = gql`
  query allDesignCollectionsQuery {
    collectionsCount
    allDesignCollections {
      ...CollectionPreviewFragment
    }
  }
  ${fragments.collection}
`;

export default graphql(AllCollectionsQuery, {
  name: 'collections',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
