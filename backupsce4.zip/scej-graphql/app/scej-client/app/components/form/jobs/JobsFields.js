import React from 'react';
import { Field } from 'redux-form/immutable';

import I from '../RenderInput';
import D from '../RenderNumber';
import S from '../SimpleSelect';
import Sw from '../RenderSwitch';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI, parsefloat as pF } from '../../../utils/libs';

export class ProcessableType extends React.Component {
  render() {
    return (
      <Field name='processable_type' component={I} {...this.props} />
    );
  }
}

export class ProcessableId extends React.Component {
  render() {
    return (
      <Field name='processable_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class SalableType extends React.Component {
  render() {
    return (
      <Field name='salable_type' component={I} {...this.props} />
    );
  }
}

export class SalableId extends React.Component {
  render() {
    return (
      <Field name='salable_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class IsExist extends React.Component {
  render() {
    return (
      <Field name='is_exist' component={Sw} type='checkbox' {...this.props} />
    );
  }
}

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' component={I} parse={pI} type='number' {...this.props} />
    );
  }
}

export class StyleId extends React.Component {
  render() {
    return (
      <Field name='style_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class ProductTypeId extends React.Component {
  render() {
    return (
      <Field name='product_type_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class LocationId extends React.Component {
  render() {
    return (
      <Field name='location_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class MaterialId extends React.Component {
  render() {
    return (
      <Field name='material_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class MetalPurityId extends React.Component {
  render() {
    return (
      <Field name='metal_purity_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class MetalColorId extends React.Component {
  render() {
    return (
      <Field name='metal_color_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Qty extends React.Component {
  render() {
    return (
      <Field name='qty' component={I} parse={pI} type='number' {...this.props} />
    );
  }
}

export class DiamondClarityId extends React.Component {
  render() {
    return (
      <Field name='diamond_clarity_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class DiamondColorId extends React.Component {
  render() {
    return (
      <Field name='diamond_color_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class CsClarityId extends React.Component {
  render() {
    return (
      <Field name='cs_clarity_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class CsColorId extends React.Component {
  render() {
    return (
      <Field name='cs_color_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Instruction extends React.Component {
  render() {
    return (
      <Field name='instruction' component={I} {...this.props} />
    );
  }
}

export class ItemSize extends React.Component {
  render() {
    return (
      <Field name='item_size' component={I} {...this.props} />
    );
  }
}

export class PriorityId extends React.Component {
  render() {
    return (
      <Field name='priority_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class DepartmentId extends React.Component {
  render() {
    return (
      <Field name='department_id' component={S} parse={pI} {...this.props} />
    );
  }
}

export class NetWeight extends React.Component {
  render() {
    return (
      <Field name='net_weight' component={D} parse={pF} {...this.props} />
    );
  }
}

export class PureWeight extends React.Component {
  render() {
    return (
      <Field name='pure_weight' component={D} parse={pF} {...this.props} />
    );
  }
}

export class DiamondPcs extends React.Component {
  render() {
    return (
      <Field name='diamond_pcs' component={I} parse={pI} type='number' {...this.props} />
    );
  }
}

export class DiamondWeight extends React.Component {
  render() {
    return (
      <Field name='diamond_weight' component={D} parse={pF} {...this.props} />
    );
  }
}

export class CsPcs extends React.Component {
  render() {
    return (
      <Field name='cs_pcs' component={I} parse={pI} type='number' {...this.props} />
    );
  }
}

export class CsWeight extends React.Component {
  render() {
    return (
      <Field name='cs_weight' component={D} parse={pF} {...this.props} />
    );
  }
}

export class GrossWeight extends React.Component {
  render() {
    return (
      <Field name='gross_weight' component={D} parse={pF} {...this.props} />
    );
  }
}

// import { ProcessableType, ProcessableId, SalableType, SalableId, IsExist, Position, StyleId, ProductTypeId, LocationId, MaterialId, MetalPurityId, MetalColorId, Qty, DiamondClarityId, DiamondColorId, CsClarityId, CsColorId, Instruction, ItemSize, PriorityId, DepartmentId, NetWeight, PureWeight, DiamondPcs, DiamondWeight, CsPcs, CsWeight, GrossWeight } from './JobsFields'; // eslint-disable-line no-unused-vars
