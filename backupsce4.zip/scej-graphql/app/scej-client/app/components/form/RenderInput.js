import React, { Component } from 'react';
import PropTypes from 'prop-types';

import { withStyles } from 'material-ui/styles';
import Input from 'material-ui/Input';
import { FormHelperText } from 'material-ui/Form';
import capitalize from '../../utils/stringEnhancer';

const styles = (theme) => ({
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    // width: 200,
  },
});

class RenderInput extends Component {
  static propTypes = {
    input: PropTypes.object.isRequired,
    meta: PropTypes.object.isRequired,
    type: PropTypes.string,
    rows: PropTypes.number,
    placeholder: PropTypes.string,
    label: PropTypes.string,
    initialValue: PropTypes.object,
    hint: PropTypes.string,
    onChange2: PropTypes.func,
    visible: PropTypes.bool,
  };

  static defaultProps = {
    // type: 'text',
    rows: 6,
    placeholder: '',
    label: '',
  };

  constructor(props) {
    super(props);
    const { label, input: { name } } = this.props;
    this.state = { label: label || capitalize(name) };
    this.input = this.input.bind(this);
  }

  input() {
    const {
      meta: { touched, error, invalid },
      input,
      input: { name },
      type,
      rows,
      placeholder,
      onChange2,
      ...custom
    } = this.props;
    if (custom) {
      custom.classes = undefined;
    } // This Key Making Problems.
    // const {classes} = this.props;

    const inputChange = (e) => {
      input.onChange(e);
      if (onChange2) {
        onChange2(e.target.value);
      }
    };

    if (this.props.visible === false) {
      return <span></span>;
    }
    if (custom) {
      custom.visible = undefined;
    } // This Key Making Problems.

    if (type === 'textarea') {
      return (
        <Input
          error={touched && invalid}
          type={type}
          rows={rows}
          id={name}
          label={this.state.label}
          placeholder={placeholder}
          multiline
          // {...input}
          name={input.name}
          onBlur={input.onBlur}
          // onChange= {input.onChange}
          onDragStart={input.onDragStart}
          onDrop={input.onDrop}
          onFocus={input.onFocus}
          value={input.value}
          onChange={inputChange}
          {...custom}
          fullWidth
        />
      );
    }

    return (
      <div>
        <Input
          error={touched && invalid}
          type={type}
          id={name}
          label={this.state.label}
          placeholder={placeholder}
          name={input.name}
          onBlur={input.onBlur}
          // onChange= {input.onChange}
          onDragStart={input.onDragStart}
          onDrop={input.onDrop}
          onFocus={input.onFocus}
          value={input.value}
          onChange={inputChange}
          {...custom}
          fullWidth
        />
        {touched &&
        error &&
        <FormHelperText error={touched && invalid}>
          {touched && error}
        </FormHelperText>}
      </div>
    );
  }

  render() {
    return (this.input());
  }
}

export default withStyles(styles)(RenderInput);
