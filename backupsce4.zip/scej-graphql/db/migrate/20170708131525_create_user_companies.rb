class CreateUserCompanies < ActiveRecord::Migration[5.1]
  def change
    create_table :user_companies do |t|
      t.references :user_contact, foreign_key: true
      t.integer :position
      t.string :slug
      t.string :company
      t.string :name
      t.string :email
      t.string :address
      t.string :gst_no

      t.timestamps
    end
    add_index :user_companies, :position
    add_index :user_companies, :slug, unique: true
    add_index :user_companies, :company, unique: true
  end
end
