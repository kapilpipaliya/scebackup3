import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  memo: gql`
    fragment MemoPreviewFragment on SaleMemo {
      id
      position
      date
      description
      created_at
    }
  `,
};

export const AllMemosQuery = gql`
  query allSaleMemosQuery {
    memosCount
    allSaleMemos {
      ...MemoPreviewFragment
    }
  }
  ${fragments.memo}
`;

export default graphql(AllMemosQuery, {
  name: 'memos',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
