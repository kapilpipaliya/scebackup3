
import validatorjs from 'validatorjs';

export default {
  plugins: { dvr: validatorjs },
  options: {
  },
  fields: [
  "position",
  "slug",
  "role"
],
  initials: {
},
  labels: {
  "position": "SN#",
  "slug": "Code",
  "role": "Role"
},
  placeholders: {
  "position": "Position",
  "slug": "Slug",
  "role": "Role"
},
  types: {
  "position": "number",
  "slug": "text",
  "role": "text"
},
  rules: {
  "position": "",
  "slug": "",
  "role": ""
},
  hooks: {
    onSuccess(form) {
      alert('Form is valid! Send the request here.');
      // get field values
      console.log('Form Values!', form.values());
    },
    onError(form) {
      alert('Form has errors!');
      // get all form errors
      console.log('All form errors', form.errors());
    }
  },
  bindings: {
}
}
