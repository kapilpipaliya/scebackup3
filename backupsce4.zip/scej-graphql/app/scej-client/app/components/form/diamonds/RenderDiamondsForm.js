import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import * as R from 'ramda';
import _ from 'lodash';
import { fromJS } from 'immutable';
import { withApollo } from 'react-apollo';
import Button from 'material-ui/Button';
import IconButton from 'material-ui/IconButton';
import DeleteIcon from 'material-ui-icons/Delete';

import DHOC from './dHOC';
import { fexecuteM } from '../../../utils/Fetch';
import { Position, MaterialId, GemShapeId, GemClarityId, ColorId, GemSizeId, Pcs, Pointer, Weight } from './DiamondsFields';
import { Footer } from '../headerfooter';
import RTable from '../ReactTable';

@DHOC
class RenderDiamonds extends Component {
  static propTypes = {
    // client: PropTypes.object,
    diamonds: PropTypes.object,
    fields: PropTypes.object,
    meta: PropTypes.object,
    change: PropTypes.func,
    calcTotals: PropTypes.func,
  };

  render() {
    const {
      fields, fields: { name }, meta: { touched, error, submitFailed }, change,
    } = this.props;
    const {
      materials, gemshapes, gemclarities, gemsizes, colors,
    } = this.props;

    const data = this.props.diamonds.toJS();
    // data.forEach(function (x) {
    //   return x["_destroy"] = false});

    const tableHash = {
      0: { accessor: '_destroy', Header: '', Cell: (p) => previewCell(p) },
      1: { Header: 'Position', Cell: (p) => positionCell(p) },
      2: { Header: 'Material', Cell: (p) => materialCell(p) },
      3: { Header: 'Shape', Cell: (p) => gemShapeCell(p) },
      4: { Header: 'Clarity', Cell: (p) => gemClarityCell(p) },
      5: { Header: 'Color', Cell: (p) => colorCell(p) },
      6: { Header: 'Size', Cell: (p) => gemSizeCell(p) },
      7: { Header: 'Pcs', Cell: (p) => gemPcsCell(p), Footer: <Footer data={data} filterColumn="pcs" precision="0" /> },
      8: { Header: 'Pointer', Cell: (p) => gemPointerCell(p) },
      9: { Header: 'Weight(Ct)', Cell: (p) => weightCell(p), Footer: <Footer data={data} filterColumn="weight" precision="3" /> },

    };
    const columns = _.map(tableHash, (v) => v);
    const fName = (p) => (`${name}[${p.index}]`);
    const previewCell = (p) => (
      <div>
        <IconButton
          color="accent"
          aria-label="Delete"
          onClick={() => {
            if (this.props.initial && data[p.index].id) {
              // fields.remove(p.index);
              change(`${fName(p)}._destroy`, true);
              this.props.calcTotals();
              // this.props.delIndex(p.index);
            } else {
              fields.remove(p.index);
              // change(`${fName(p)}._destroy`, true);
              this.props.calcTotals();
              this.props.delIndex(p.index);
            }
          }}
        >
          <DeleteIcon />
        </IconButton>
      </div>
    );
    const positionCell = (p) => <Position name={`${fName(p)}.position`} />;
    const materialCell = (p) => <MaterialId name={`${fName(p)}.material_id`} options={materials.get(p.index)} onChange2={(v) => { this.props.fetchMChange(p.index, v); this.props.calcTotals(); }} />;
    const gemShapeCell = (p) => <GemShapeId name={`${fName(p)}.gem_shape_id`} options={gemshapes.get(p.index)} onChange2={(sId) => this.props.fetchShClChange(p.index, data[p.index].material_id, sId, data[p.index].gem_clarity_id)} />;
    const gemClarityCell = (p) => <GemClarityId name={`${fName(p)}.gem_clarity_id`} options={gemclarities.get(p.index)} onChange2={(cId) => this.props.fetchShClChange(p.index, data[p.index].material_id, data[p.index].gem_shape_id, cId)} />;
    const colorCell = (p) => <ColorId name={`${fName(p)}.color_id`} options={colors.get(p.index)} />;
    const gemSizeCell = (p) => (
      <GemSizeId
        name={`${fName(p)}.gem_size_id`}
        options={gemsizes.get(p.index)}
        onChange2={(weight) => {
          const pointer = gemsizes.get(p.index)[weight].carat_weight;
          change(`${fName(p)}.pointer`, pointer);
          change(`${fName(p)}.weight`, data[p.index].pcs * pointer);
          this.props.calcTotals();
        }}
      />
    );
    const gemPcsCell = (p) => (
      <Pcs
        name={`${fName(p)}.pcs`}
        onChange2={(pcs) => {
          change(`${fName(p)}.weight`, pcs * data[p.index].pointer);
          this.props.calcTotals();
        }}
      />
    );

    const gemPointerCell = (p) => <Pointer name={`${fName(p)}.pointer`} disabled onChange2={(pointer) => change(`${fName(p)}.weight`, data[p.index].pcs * pointer)} />;
    const weightCell = (p) => <Weight name={`${fName(p)}.weight`} disabled />;

    return (
      <div>
        <h2>Diamonds:</h2>
        <Button
          raised
          color="primary"
          type="button"
          onClick={() => {
            fields.push(fromJS({ _destroy: false }));
            const i = fields.length;
            this.props.fetchIndex(i, fexecuteM, 'materials', 2); // Fetch Materials.
            this.props.fetchMChange(i, 4); // Fetch Shape, Clarity, Color.
          }}
        >Add Diamond
        </Button>
        {(touched || submitFailed) && error && <span>{error}</span>}
        <RTable
          data={data}
          columns={columns}
          defaultPageSize={10}
          sortable={false}
        />
      </div>
    );
  }
}
export default withApollo(RenderDiamonds);
