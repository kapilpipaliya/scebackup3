import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  mTxnType: gql`
    fragment MTxnTypePreviewFragment on SaleMTxnType {
      id
      position
      slug
      txn_type
      created_at
    }
  `,
};

export const AllMTxnTypesQuery = gql`
  query allSaleMTxnTypesQuery {
    mTxnTypesCount
    allSaleMTxnTypes {
      ...MTxnTypePreviewFragment
    }
  }
  ${fragments.mTxnType}
`;

export default graphql(AllMTxnTypesQuery, {
  name: 'mtxntypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
