yarn
npm rebuild
yarn run build:dll
yarn start