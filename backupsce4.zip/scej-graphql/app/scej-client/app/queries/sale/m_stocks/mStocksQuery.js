import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const AllMStocksQuery = gql`
  query allSaleMStocksQuery {
    allSaleMStocks {
      id
    }
  }
`;

export default graphql(AllMStocksQuery, {
  name: 'mstocks',
});
