import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  material: gql`
    fragment MaterialFragment on MaterialMaterial {
      id
      material_type_id { id slug }
      position
      slug
      material_name
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_MATERIAL = gql`
    query getMaterial($id: ID) {
      material(id: $id) {
        ...MaterialFragment
      }
    }
    ${fragments.material}
  `;

  const withMaterial = graphql(GET_MATERIAL, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMaterial(WrappedComponent);
}
