import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  metalPurity: gql`
    fragment MetalPurityPreviewFragment on MaterialMetalPurity {
      id
      material_id { id slug }
      position
      slug
      name
      purity
      specific_density
      price
      description
      created_at
    }
  `,
};

export const AllMetalPuritiesQuery = gql`
  query allMaterialMetalPuritiesQuery($f_material_id: Int) {
    metalPuritiesCount
    allMaterialMetalPurities(f_material_id: $f_material_id) {
      ...MetalPurityPreviewFragment
    }
  }
  ${fragments.metalPurity}
`;

export default graphql(AllMetalPuritiesQuery, {
  name: 'metalpurities',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_material_id: 0 },
  }),
});
