import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  contact: gql`
    fragment ContactPreviewFragment on UserContact {
      id
      position
      slug
      first_name
      last_name
      email
      phone
      mobile
      salary
      created_at
    }
  `,
};

export const AllContactsQuery = gql`
  query allUserContactsQuery {
    contactsCount
    allUserContacts {
      ...ContactPreviewFragment
    }
  }
  ${fragments.contact}
`;

export default graphql(AllContactsQuery, {
  name: 'contacts',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
