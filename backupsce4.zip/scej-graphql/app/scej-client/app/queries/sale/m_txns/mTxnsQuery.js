import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  mTxn: gql`
    fragment MTxnPreviewFragment on SaleMTxn {
      id
      position
      m_txn_type_id { id slug }
      party_id { id slug }
      taken_by_id { id slug }
      date
      due_date
      total_weight
      amount
      description
      created_at
    }
  `,
};

export const AllMTxnsQuery = gql`
  query allSaleMTxnsQuery {
    mTxnsCount
    allSaleMTxns {
      ...MTxnPreviewFragment
    }
  }
  ${fragments.mTxn}
`;

export default graphql(AllMTxnsQuery, {
  name: 'mtxns',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
