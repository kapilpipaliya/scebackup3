import React from 'react';
import { List } from 'immutable';
import { fexecuteM, fexecuteMChange, fexecuteShapeorClarityChange } from '../../../utils/Fetch';
import { parseint as pI } from '../../../utils/libs';

const HOCFetch = (InnerComponent) => class extends React.Component {
  state = {
    materials: List(),
    gemshapes: List(),
    gemclarities: List(),
    gemsizes: List(),
    colors: List(),
  }

  componentDidMount() {
    if (this.props.initial) {
      this.props.initial.toJS().forEach((item, index) => {
        this.executeGeneral(index, fexecuteM, 'materials', 2);
        this.executeMChange(index, pI(item.material_id, 10)); // Fetch Shape, Clarity, Color.
        this.executeShapeorClarityChange(index, pI(item.material_id, 10), pI(item.gem_shape_id, 10), pI(item.gem_clarity_id, 10)); // Fetch Shape, Clarity, Color.
      });
    }
  }
  executeGeneral = async (index, fn, mystate, id) => {
    this.setState((prevState) => { prevState[mystate].set(index, { }); });
    const d = await fn(this.props.client, id);
    this.setState((prevState) => {
      const k = prevState[mystate].set(index, d);
      return { [mystate]: k };
    });
  };
  executeMChange = async (index, mID) => {
    this.setState((prevState) => {
      prevState.gemshapes.set(index, {});
      prevState.gemclarities.set(index, {});
      prevState.colors.set(index, {});
    });
    const d = await fexecuteMChange(this.props.client, mID);
    this.setState((prevState) => (
      {
        gemshapes: prevState.gemshapes.set(index, d.gemshapes),
        gemclarities: prevState.gemclarities.set(index, d.gemclarities),
        colors: prevState.colors.set(index, d.colors),
      }
    ));
  };
  executeShapeorClarityChange = async (index, mID, shapeId, clarityId) => {
    this.setState((prevState) => { prevState.gemsizes.set(index, {}); });
    const d = await fexecuteShapeorClarityChange(this.props.client, mID, shapeId, clarityId);
    this.setState((prevState) => ({ gemsizes: prevState.gemsizes.set(index, d) }));
  }

  delIndex = (index) => {
    this.setState((prevState) => ({
      materials: prevState.materials.delete(index),
      gemshapes: prevState.gemshapes.delete(index),
      gemclarities: prevState.gemclarities.delete(index),
      gemsizes: prevState.gemsizes.delete(index),
      colors: prevState.colors.delete(index),
    }));
  };

  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
        fetchIndex={this.executeGeneral}
        fetchMChange={this.executeMChange}
        fetchShClChange={this.executeShapeorClarityChange}
        delIndex={this.delIndex}
      />
    );
  }
};

export default HOCFetch;
