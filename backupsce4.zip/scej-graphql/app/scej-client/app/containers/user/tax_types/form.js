
import validatorjs from 'validatorjs';

export default {
  plugins: { dvr: validatorjs },
  options: {
  },
  fields: [
  "position",
  "slug"
],
  initials: {
},
  labels: {
  "position": "SN#",
  "slug": "Code"
},
  placeholders: {
  "position": "Position",
  "slug": "Slug"
},
  types: {
  "position": "number",
  "slug": "text"
},
  rules: {
  "position": "",
  "slug": ""
},
  hooks: {
    onSuccess(form) {
      alert('Form is valid! Send the request here.');
      // get field values
      console.log('Form Values!', form.values());
    },
    onError(form) {
      alert('Form has errors!');
      // get all form errors
      console.log('All form errors', form.errors());
    }
  },
  bindings: {
}
}
