import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  role: gql`
    fragment RoleForEditingFragment on UserRole {
      id
      position
      slug
      role
    }
  `,
};

export default function (WrappedComponent) {
  const GET_ROLE = gql`
    query getRole($id: ID) {
      role(id: $id) {
        ...RoleForEditingFragment
      }
    }
    ${fragments.role}
  `;

  const withRoleForEditing = graphql(GET_ROLE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withRoleForEditing(WrappedComponent);
}
