import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import D from '../../../components/form/RenderNumber';
import S from '../../../components/form/SimpleSelect';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI, parsefloat as pF } from '../../../utils/libs';

export class UserTaxTypeId extends React.Component {
  render() {
    return (
      <Field name='user_tax_type_id' label='User tax type' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Slug extends React.Component {
  render() {
    return (
      <Field name='slug' label='Code' component={F} {...this.props} />
    );
  }
}

export class Rate extends React.Component {
  render() {
    return (
      <Field name='rate' label='Rate' component={D} parse={pF} placeholder='Rate' {...this.props} />
    );
  }
}

// import { UserTaxTypeId, Position, Slug, Rate } from './_TaxRateFields'; // eslint-disable-line no-unused-vars
