
import validatorjs from 'validatorjs';

export default {
  plugins: { dvr: validatorjs },
  options: {
  },
  fields: [
  "user_tax_type_id",
  "position",
  "slug",
  "rate"
],
  initials: {
},
  labels: {
  "user_tax_type_id": "User tax type",
  "position": "SN#",
  "slug": "Code",
  "rate": "Rate"
},
  placeholders: {
  "user_tax_type_id": "User tax type",
  "position": "Position",
  "slug": "Slug",
  "rate": "Rate"
},
  types: {
  "user_tax_type_id": "number",
  "position": "number",
  "slug": "text",
  "rate": "number"
},
  rules: {
  "user_tax_type_id": "",
  "position": "",
  "slug": "",
  "rate": ""
},
  hooks: {
    onSuccess(form) {
      alert('Form is valid! Send the request here.');
      // get field values
      console.log('Form Values!', form.values());
    },
    onError(form) {
      alert('Form has errors!');
      // get all form errors
      console.log('All form errors', form.errors());
    }
  },
  bindings: {
}
}
