import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  color: gql`
    fragment ColorForEditingFragment on MaterialColor {
      id
      material_id { id slug }
      position
      slug
      color
    }
  `,
};

export default function (WrappedComponent) {
  const GET_COLOR = gql`
    query getColor($id: ID) {
      color(id: $id) {
        ...ColorForEditingFragment
      }
    }
    ${fragments.color}
  `;

  const withColorForEditing = graphql(GET_COLOR, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withColorForEditing(WrappedComponent);
}
