import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import Input, { InputLabel } from 'material-ui/Input';
// import { MenuItem } from 'material-ui/Menu';
import { FormControl, FormHelperText } from 'material-ui/Form';
import Select from 'material-ui/Select';

import capitalize from '../../utils/stringEnhancer';

const styles = (theme) => ({
  formControl: {
    marginRight: theme.spacing.unit,
    // minWidth: 200,
  },
});


class SimpleSelect extends React.Component {
  static propTypes = {
    input: PropTypes.object.isRequired,
    meta: PropTypes.object.isRequired,
    type: PropTypes.string,
    rows: PropTypes.number,
    placeholder: PropTypes.string,
    label: PropTypes.string,
    initialValue: PropTypes.object,
    hint: PropTypes.string,
    onChange2: PropTypes.func,
    oField: PropTypes.string,
    options: PropTypes.any,
    classes: PropTypes.object,
    visible: PropTypes.bool,
  }
  constructor(props) {
    super(props);
    const { label, input: { name }, oField } = this.props;
    this.state = { label: label || capitalize(name), option_field: oField || 'slug' };
    this.input = this.input.bind(this);
  }
  handleChange = (name) => (event) => {
    this.setState({ [name]: event.target.value });
  };


  input() {
    const {
      meta: { touched, error, invalid },
      input,
      input: { name },
      placeholder,
      onChange2,
      ...custom
    } = this.props;
    const { classes } = this.props;
    if (custom) {
      delete custom.classes;
      delete custom.oField;
    } // This Key Making Problems.

    const inputChange = (e) => {
      input.onChange(e);
      if (onChange2) {
        onChange2(parseInt(e.target.value, 10));
      }
    };

    if (this.props.visible === false) {
      return <span></span>;
    }
    if (custom) {
      custom.visible = undefined;
    } // This Key Making Problems.

    return (
      <FormControl
        className={classes.formControl}
        error={touched && invalid}
        fullWidth
      >
        {this.props.label && <InputLabel htmlFor={name}>{this.state.label}</InputLabel>}
        <Select
          native
          // value={this.state.select_value}
          // //onChange={this.handleChange('select_value')}
          name={input.name}
          onBlur={input.onBlur}
          // onChange= {input.onChange}
          onDragStart={input.onDragStart}
          onDrop={input.onDrop}
          onFocus={input.onFocus}
          value={input.value}
          onChange={inputChange}
          placeholder={placeholder}
          input={<Input id={name} />}
          {...custom}
        >
          <option value="0" />
          {this.renderOptions()}
        </Select>
        {touched &&
        error &&
        <FormHelperText>{error}</FormHelperText>}
      </FormControl>
    );
  }
  renderOptions() {
    // The Magical Lodash
    return _.map(this.props.options, (option) => (
      <option key={parseInt(option.id, 10)} value={parseInt(option.id, 10)}>
        {option[this.state.option_field]}
      </option>
    ));
  }
  render() {
    return (this.input());
  }
}

export default withStyles(styles)(SimpleSelect);
