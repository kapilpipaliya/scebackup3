export default {
  getPost(state = [], { mutationResult }) {
    const { createComment } = mutationResult.data;

    if (createComment) {
      const { newComment } = createComment;
      if (!newComment) {
        return null;
      }
      return {
        post: {
          // ...state.post,
          comments: [newComment, ...state.post.comments],
        },
      };
    }

    return state;
  },
};
