import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withAddress from '../../../queries/user/addresses/addressQuery';

class Address extends Component {
  render() {
    const { address, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="address">
        <p>Address</p>
        <h2 className="address-heading">{address.slug}</h2>
        <div className="address-meta">
          <span className="address-author">
            Posted by: <em>{/* {address.author.name} */}</em>
          </span>
          <span className="address-date">
            {moment(new Date(address.created_at)).fromNow()}
          </span>
        </div>
        <div className="address-content">
          contents display here: ID : {address.id}
        </div>
      </article>
    );
  }
}

export default withAddress(Address);
