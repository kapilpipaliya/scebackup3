import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  collection: gql`
    fragment CollectionForEditingFragment on DesignCollection {
      id
      position
      slug
      collection
      parent_id { id slug }
    }
  `,
};

export default function (WrappedComponent) {
  const GET_COLLECTION = gql`
    query getCollection($id: ID) {
      collection(id: $id) {
        ...CollectionForEditingFragment
      }
    }
    ${fragments.collection}
  `;

  const withCollectionForEditing = graphql(GET_COLLECTION, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withCollectionForEditing(WrappedComponent);
}
