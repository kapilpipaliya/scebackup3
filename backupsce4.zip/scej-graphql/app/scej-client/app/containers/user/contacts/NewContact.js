import React, { Component } from 'react';
import Button from 'material-ui/Button';
import ContactForm from './_ContactForm';
import withCreateContact from '../../../mutations/user/contacts/createContactMutation';

class NewContact extends Component {
  render() {
    return (
      <div>
        <h1>New Contact</h1>
        <ContactForm action={this.props.createContact} submitName="Create Contact" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateContact(NewContact);
