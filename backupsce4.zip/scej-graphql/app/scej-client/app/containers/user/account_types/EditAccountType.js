import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import AccountTypeForm from './_AccountTypeForm';
import withAccountTypeForEditing from '../../../queries/user/account_types/accountTypeForEditingQuery';
import withUpdateAccountType from '../../../mutations/user/account_types/updateAccountTypeMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditAccountType extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { accountType, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing accountType</h1>
        <AccountTypeForm action={this.props.updateAccountType} initialValues={{ ...flatIDValue(accountType) }} submitName="Update AccountType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withAccountTypeForEditing(withUpdateAccountType(EditAccountType));
