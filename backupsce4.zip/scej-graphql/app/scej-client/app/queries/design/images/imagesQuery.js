import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  image: gql`
    fragment ImagePreviewFragment on DesignImage {
      id
      imageable_type
      imageable_id { id slug }
      image
      created_at
    }
  `,
};

export const AllImagesQuery = gql`
  query allDesignImagesQuery {
    imagesCount
    allDesignImages {
      ...ImagePreviewFragment
    }
  }
  ${fragments.image}
`;

export default graphql(AllImagesQuery, {
  name: 'images',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
