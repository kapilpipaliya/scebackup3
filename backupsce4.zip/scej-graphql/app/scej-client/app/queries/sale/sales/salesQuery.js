import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  sale: gql`
    fragment SalePreviewFragment on SaleSale {
      id
      position
      customer_id { id slug }
      sold_by_id { id slug }
      date
      due_date
      description
      net_weight
      pure_weight
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      tax
      discount
      amount
      created_at
    }
  `,
};

export const AllSalesQuery = gql`
  query allSaleSalesQuery {
    salesCount
    allSaleSales {
      ...SalePreviewFragment
    }
  }
  ${fragments.sale}
`;

export default graphql(AllSalesQuery, {
  name: 'sales',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
