import React from 'react';
import { observer } from 'mobx-react';
import _ from 'lodash';
import Grid from 'material-ui/Grid';
import { withApollo } from 'react-apollo';
import FormControls from '../../../components/controls/FormControls';
import MaterialTextField from '../../../components/inputs/MaterialTextField';
import SimpleSelectMaterial from '../../../components/inputs/SimpleSelectMaterial';

import { AllAccountsQuery } from '../../../queries/user/accounts/accountsQuery';
import { AllStatesQuery } from '../../../queries/user/states/statesQuery';
import { AllCountriesQuery } from '../../../queries/user/countries/countriesQuery';
// Part1
// Part1

@withApollo
@observer
class Form extends React.Component {
  componentDidMount() {
    this._componenDidMount();
  }
  async _componenDidMount() {
    this.fetchAccounts('account_id', 1)
    this.fetchStates('state_id', 1)
    this.fetchCountries('country_id', 1)
  }

  fetchAccounts = async (field ) => {
    const accounts = await this.props.client.query({
      query: AllAccountsQuery,
      variables: {},
    });
    this.props.form.set('extra', {
      [field]: _.mapKeys(accounts.data.allUserAccounts, (value) => value.id)
    })
  }

  fetchStates = async (field ) => {
    const states = await this.props.client.query({
      query: AllStatesQuery,
      variables: {},
    });
    this.props.form.set('extra', {
      [field]: _.mapKeys(states.data.allUserStates, (value) => value.id)
    })
  }

  fetchCountries = async (field ) => {
    const countries = await this.props.client.query({
      query: AllCountriesQuery,
      variables: {},
    });
    this.props.form.set('extra', {
      [field]: _.mapKeys(countries.data.allUserCountries, (value) => value.id)
    })
  }
// Part2
// Part2

  render(){
  
  const {form, action} = this.props;
  
  // if(this.props.initialValues) {
  //   form.set('value', this.props.initialValues)
  // }
  
  const hooks = {
    onSuccess(form) {
      // alert('submitting....');

      return action(form.values()).then((errors) => {
        if (errors) {
          form.set('error', errors);
          
          Object.keys(errors).forEach((v) => {
            form.$(v).invalidate(errors[v])
          });
          // form.invalidate('This is a generic error message!');
          
        } else {
          form.clear()
        }
      })
    }
  }
    
  return(
    <form>
      <fieldset>
        <Grid container spacing={24}>
          <Grid item xs={12}><SimpleSelectMaterial field={form.$('account_id')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('position')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('firstname')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('lastname')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('address1')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('address2')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('city')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('zipcode')} /></Grid>
          <Grid item xs={12}><SimpleSelectMaterial field={form.$('state_id')} /></Grid>
          <Grid item xs={12}><SimpleSelectMaterial field={form.$('country_id')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('phone')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('alternative_phone')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('company')} /></Grid>
        </Grid>
        <FormControls form={form} hooks={hooks}/>
      </fieldset>
    </form>
  )}
}

export default Form;
