import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  memo: gql`
    fragment MemoFragment on SaleMemo {
      id
      position
      date
      description
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_MEMO = gql`
    query getMemo($id: ID) {
      memo(id: $id) {
        ...MemoFragment
      }
    }
    ${fragments.memo}
  `;

  const withMemo = graphql(GET_MEMO, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMemo(WrappedComponent);
}
