import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withTaxRatesData from '../../../queries/user/tax_rates/taxRatesQuery';

import ListTaxRates from './_ListTaxRates';
import HeadListTaxRates from './_HeadListTaxRates';

class AllTaxRates extends Component {
  componentDidMount() {
    this.props.taxrates.refetch(); // You can pass variables here.
  }

  render() {
    const { taxrates: { loading, error }, taxrates } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListTaxRates />
        <ListTaxRates data={taxrates} />
      </div>
    );
  }
}

export default withTaxRatesData(AllTaxRates);
