import React from 'react';
import { CircularProgress } from 'material-ui/Progress';

export default () => <div><CircularProgress size={80} thickness={5} /></div>;
