import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Field } from 'redux-form/immutable';
// import * as R from 'ramda';
import { fromJS, List } from 'immutable';
import { withApollo } from 'react-apollo';
import Button from 'material-ui/Button';
import IconButton from 'material-ui/IconButton';
import Icon from 'material-ui/Icon';
import Typography from 'material-ui/Typography';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';

import RenderInput from './RenderInput';
import S from '../../components/form/SimpleSelect';
import Sw from '../../components/form/RenderSwitch';

import { parseint as pI, parsefloat as pF } from '../../utils/libs';
import { fexecuteM, fexecuteMChange, fexecuteShapeorClarityChange, fexecuteLocations, fexecuteLocker, fexecuteAccessory, fexecuteGemType } from '../../utils/Fetch';


class RenderMTxns extends Component {
  static propTypes = {
    meta: PropTypes.object.isRequired,
    client: PropTypes.object,
    fields: PropTypes.object,
    change: PropTypes.func,
    mTxnDetails: PropTypes.object,
    calcTotals: PropTypes.func,
  };
  state = {
    materials: List(), metalpurities: List(), gemshapes: List(), gemclarities: List(), gemsizes: List(), colors: List(), locations: List(), lockers: List(), accessories: List(), gemtypes: List(),
  }
  // Do Initial Loading of Options.
  componentDidMount() {
    if (this.props.mTxnDetails) {
      this.props.mTxnDetails.forEach((item, index) => {
        this.executeGeneral(index, fexecuteM, 'materials', 0); // Fetch Materials.
        this.executeMChange(index, parseInt(item.material_id, 10)); // Fetch Shape, Clarity, Color.
        // this.executePChange(index, parseInt(item.material_id, 10)) // Fetch Shape, Clarity, Color.
        this.executeShapeorClarityChange(index, parseInt(item.material_id, 10), parseInt(item.gem_shape_id, 10), parseInt(item.gem_clarity_id, 10)); // Fetch Shape, Clarity, Color.
        this.executeGeneral(index, fexecuteLocations, 'locations');
        this.executeGeneral(index, fexecuteAccessory, 'accessories');
        this.executeGeneral(index, fexecuteGemType, 'gemtypes');
      });
    }
  }
  checkboxToogle = (row) => {
    const name = `${this.props.fields.name}[${row}]`;
    this.props.change(`${name}.position`, '');
  };
  executeGeneral = async (index, fn, mystate, id) => {
    const d = await fn(this.props.client, id);
    this.setState((prevState) => ({ [mystate]: prevState[mystate].set(index, d) }));
  };
  executeMChange = async (index, mID) => {
    const d = await fexecuteMChange(this.props.client, mID);
    this.setState((prevState) => (
      {
        metalpurities: prevState.metalpurities.set(index, d.metalpurities),
        gemshapes: prevState.gemshapes.set(index, d.gemshapes),
        gemclarities: prevState.gemclarities.set(index, d.gemclarities),
        colors: prevState.colors.set(index, d.colors),
      }
    ));
  };
  executePChange = async (index, value) => {
    const { change } = this.props;
    const name = `${this.props.fields.name}[${index}]`;
    if (value) {
      const purityPer = this.state.metalpurities.get(index)[value].purity;
      const { weight } = this.props.mTxnDetails.get(index);
      change(`${name}.purityPer`, this.state.metalpurities.get(index)[value].purity);
      change(`${name}.pure_weight`, (purityPer * weight) / 100);
    } else {
      change(`${name}.purityPer`, 0);
      change(`${name}.pure_weight`, 0);
    }
  };
  executeShapeorClarityChange = async (index, mID, shapeId, clarityId) => {
    const d = await fexecuteShapeorClarityChange(this.props.client, mID, shapeId, clarityId);
    this.setState((prevState) => ({ gemsizes: prevState.gemsizes.set(index, d) }));
  }


  render() {
    const { fields, meta: { touched, error, submitFailed }, change } = this.props;
    const data = this.props.mTxnDetails.toJS();
    const {
      materials, metalpurities, gemshapes, gemclarities, gemsizes, colors, locations, lockers, accessories, gemtypes,
    } = this.state;

    const metalCheck = (index) => (
      [4, 5].includes(data[index].material_id) ? 1 : 0
    );
    const gemCheck = (index) => (
      [1, 2, 3].includes(data[index].material_id) ? 1 : 0
    );
    const columns = [
      // @formatter:off
      { Header: '', Cell: (props) => (<Typography type="body2" style={{ textAlign: 'center' }}>{props.index + 1} <IconButton color="accent" aria-label="Delete" onClick={() => { fields.remove(props.index); this.props.calcTotals(); }} > <Icon color="primary" style={{ fontSize: 30 }}>delete_forever</Icon></IconButton></Typography>) },
      { Header: 'Position', Cell: (props) => <Field name={`${fields.name}[${props.index}].position`} component={RenderInput} type="number" /> },
      { Header: 'Material', Cell: (props) => <Field name={`${fields.name}[${props.index}].material_id`} component={S} parse={pI} options={materials.get(props.index)} onChange2={(value) => this.executeMChange(props.index, value)} /> },
      { Header: 'Purity', Cell: (props) => <Field name={`${fields.name}[${props.index}].metal_purity_id`} component={S} parse={pI} options={metalpurities.get(props.index)} onChange2={(value) => this.executePChange(props.index, value)} visible={!metalCheck(props.index)} /> },
      { Header: 'Shape', Cell: (props) => <Field name={`${fields.name}[${props.index}].gem_shape_id`} component={S} parse={pI} options={gemshapes.get(props.index)} onChange2={(sId) => this.executeShapeorClarityChange(props.index, data[props.index].material_id, sId, data[props.index].gem_clarity_id)} visible={!gemCheck(props.index)} /> },

      { Header: 'Clarity', Cell: (props) => <Field name={`${fields.name}[${props.index}].gem_clarity_id`} component={S} parse={pI} options={gemclarities.get(props.index)} onChange2={(cId) => this.executeShapeorClarityChange(props.index, data[props.index].material_id, data[props.index].gem_shape_id, cId)} visible={!gemCheck(props.index)} /> },
      { Header: 'Color', Cell: (props) => <Field name={`${fields.name}[${props.index}].color_id`} component={S} parse={pI} options={colors.get(props.index)} /> },
      { Header: 'Size', Cell: (props) => <Field name={`${fields.name}[${props.index}].gem_size_id`} component={S} parse={pI} options={gemsizes.get(props.index)} visible={!gemCheck(props.index)} /> },
      { Header: 'Location', Cell: (props) => <Field name={`${fields.name}[${props.index}].location_id`} component={S} parse={pI} options={locations.get(props.index)} onChange2={(value) => this.executeGeneral(props.index, fexecuteLocker, 'lockers', value)} /> },
      { Header: 'Locker', Cell: (props) => <Field name={`${fields.name}[${props.index}].locker_id`} component={S} parse={pI} options={lockers.get(props.index)} /> },
      { Header: 'Accessory', Cell: (props) => <Field name={`${fields.name}[${props.index}].accessory_id`} component={S} parse={pI} options={accessories.get(props.index)} visible={!metalCheck(props.index)} /> },
      { Header: 'Issue? *', Cell: (props) => <Field name={`jobs[${props.index}].isissue`} component={Sw} type="checkbox" onChange2={(v) => { this.checkboxToogle(props.index, v); }} /> },
      { Header: 'Customer Stock ', Cell: (props) => <Field name={`jobs[${props.index}].customer_stock`} component={Sw} type="checkbox" onChange2={(v) => { this.checkboxToogle(props.index, v); }} visible={!gemCheck(props.index)} /> },
      { Header: 'Available Pcs', Cell: (props) => <Field name={`${fields.name}[${props.index}].weight`} component={RenderInput} parse={pF} disabled visible={!gemCheck(props.index)} /> },
      { Header: 'Available Wt', Cell: (props) => <Field name={`${fields.name}[${props.index}].weight`} component={RenderInput} parse={pF} disabled /> },
      {
        Header: 'Pcs',
        Cell: (props) => (<Field
          name={`${fields.name}[${props.index}].pcs`}
          component={RenderInput}
          parse={pI}
          visible={!gemCheck(props.index)}
          onChange2={(pcs) => {
            change(`${fields.name}[${props.index}].weight`, pcs * data[props.index].pointer);
            this.props.calcTotals();
          }}
        />),
      },
      // {Header: 'Pointer', Cell: props => <Field name={`${fields.name}[${props.index}].pointer`} component={RenderInput} parse={pF} disabled onChange2={(pointer) => change(`${fields.name}[${props.index}].weight`, data[props.index].pcs * pointer)}/>},
      {
        Header: 'Weight',
        Cell: (props) => (<Field
          name={`${fields.name}[${props.index}].weight`}
          component={RenderInput}
          parse={pF}
          onChange2={(value) => {
            const name = `${this.props.fields.name}[${props.index}]`;
            // if material Calculate Pure wt
            if ([1, 2, 3].includes(data[props.index].material_id)) {
              const { purityPer } = data[props.index];
              change(`${name}.pure_weight`, (purityPer * value) / 100);
            }
            change(`${name}.amount`, value * data[props.index].rate1);
          }}
        />),
      },
      { Header: 'Purity(%)', Cell: (props) => <Field name={`${fields.name}[${props.index}].purityPer`} component={RenderInput} parse={pF} disabled visible={!metalCheck(props.index)} /> },
      { Header: 'Pure Wt', Cell: (props) => <Field name={`${fields.name}[${props.index}].pure_weight`} component={RenderInput} parse={pF} disabled visible={!metalCheck(props.index)} /> },
      { Header: 'Note', Cell: (props) => <Field name={`${fields.name}[${props.index}].note`} component={RenderInput} parse={pF} /> },
      { Header: 'Gem Type', Cell: (props) => <Field name={`${fields.name}[${props.index}].gem_type_id`} component={S} parse={pI} options={gemtypes.get(props.index)} visible={!gemCheck(props.index)} /> },
      { Header: 'Rate On Pcs? *', Cell: (props) => <Field name={`jobs[${props.index}].rate_on_pc`} component={Sw} type="checkbox" onChange2={(v) => { this.checkboxToogle(props.index, v); }} visible={!gemCheck(props.index)} /> },
      {
        Header: 'Rate',
        Cell: (props) => (<Field
          name={`${fields.name}[${props.index}].rate1`}
          component={RenderInput}
          parse={pF}
          onChange2={(value) => {
            const name = `${this.props.fields.name}[${props.index}]`;
            change(`${name}.amount`, data[props.index].weight * value);
          }}
        />),
      },
      { Header: 'Amount', Cell: (props) => <Field name={`${fields.name}[${props.index}].amount`} component={RenderInput} parse={pF} disabled /> },
    // @formatter:on
    ];

    return (
      <div>
        <h2>Details:</h2>
        <Button
          raised
          color="primary"
          type="button"
          onClick={() => {
            fields.push(fromJS({}));
            const i = fields.length;
            this.executeGeneral(i, fexecuteM, 'materials', 0); // Fetch Materials.
            this.executeMChange(i, 4); // Fetch Shape, Clarity, Color.
            this.executeGeneral(i, fexecuteLocations, 'locations');
            this.executeGeneral(i, fexecuteAccessory, 'accessories');
            this.executeGeneral(i, fexecuteGemType, 'gemtypes');
          }
          }
        >
          Add Details:
        </Button>
        {(touched || submitFailed) && error && <span>{error}</span>}
        <ReactTable
          data={data}
          columns={columns}
          defaultPageSize={10}
        />
      </div>
    );
  }
}

export default withApollo(RenderMTxns);
