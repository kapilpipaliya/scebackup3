import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  taxRate: gql`
    fragment TaxRatePreviewFragment on UserTaxRate {
      id
      user_tax_type_id { id slug }
      position
      slug
      rate
      created_at
    }
  `,
};

export const AllTaxRatesQuery = gql`
  query allUserTaxRatesQuery {
    taxRatesCount
    allUserTaxRates {
      ...TaxRatePreviewFragment
    }
  }
  ${fragments.taxRate}
`;

export default graphql(AllTaxRatesQuery, {
  name: 'taxrates',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
