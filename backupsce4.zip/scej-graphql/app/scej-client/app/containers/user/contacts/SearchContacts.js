import React, { Component } from 'react';
import ListContacts from './_ListContacts';
import HeadListContacts from './_HeadListContacts';
import withContactsData from '../../../queries/user/contacts/contactsQuery';

class SearchContacts extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.contacts = [];
    }
  }

  render() {
    const { contacts, contactsCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreContacts,
      firstContactsLoading,
    } = this.props;

    return (
      <div className="search-contacts">
        <h1>Searching contacts</h1>
        <HeadListContacts
          initialKeywords={keywords}
          loading={firstContactsLoading}
        />

        {!firstContactsLoading && contacts && contacts.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListContacts
            contacts={contacts}
            contactsCount={contactsCount}
            loading={loading}
            loadMoreContacts={loadMoreContacts}
          />
        )}
      </div>
    );
  }
}

export default withContactsData(SearchContacts);
