
import validatorjs from 'validatorjs';

export default {
  plugins: { dvr: validatorjs },
  options: {
  },
  fields: [
  "account_id",
  "position",
  "firstname",
  "lastname",
  "address1",
  "address2",
  "city",
  "zipcode",
  "state_id",
  "country_id",
  "phone",
  "alternative_phone",
  "company"
],
  initials: {
},
  labels: {
  "account_id": "Account",
  "position": "SN#",
  "firstname": "Firstname",
  "lastname": "Lastname",
  "address1": "Address1",
  "address2": "Address2",
  "city": "City",
  "zipcode": "Zipcode",
  "state_id": "State",
  "country_id": "Country",
  "phone": "Phone",
  "alternative_phone": "Alternative phone",
  "company": "Company"
},
  placeholders: {
  "account_id": "Account",
  "position": "Position",
  "firstname": "Firstname",
  "lastname": "Lastname",
  "address1": "Address1",
  "address2": "Address2",
  "city": "City",
  "zipcode": "Zipcode",
  "state_id": "State",
  "country_id": "Country",
  "phone": "Phone",
  "alternative_phone": "Alternative phone",
  "company": "Company"
},
  types: {
  "account_id": "number",
  "position": "number",
  "firstname": "text",
  "lastname": "text",
  "address1": "text",
  "address2": "text",
  "city": "text",
  "zipcode": "text",
  "state_id": "number",
  "country_id": "number",
  "phone": "text",
  "alternative_phone": "text",
  "company": "text"
},
  rules: {
  "account_id": "",
  "position": "",
  "firstname": "",
  "lastname": "",
  "address1": "",
  "address2": "",
  "city": "",
  "zipcode": "",
  "state_id": "",
  "country_id": "",
  "phone": "",
  "alternative_phone": "",
  "company": ""
},
  hooks: {
    onSuccess(form) {
      alert('Form is valid! Send the request here.');
      // get field values
      console.log('Form Values!', form.values());
    },
    onError(form) {
      alert('Form has errors!');
      // get all form errors
      console.log('All form errors', form.errors());
    }
  },
  bindings: {
}
}
