import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import AccountPreview from './_AccountPreview';

class ListAccounts extends Component {
  state = {
    variables: { f_a_type_id: 0 },
  }
  render() {
    const {
      allUserAccounts,
      // accountsCount,
      loading,
      error,
      // loadMoreAccounts,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allUserAccounts}
        columns={[
          // @formatter:off
          { accessor: 'AccountPreview', Header: '-', Cell: (props) => <AccountPreview accountRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { Header: 'Account type', Cell: (props) => (props.original.account_type_id ? props.original.account_type_id.slug : undefined) },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'join_date', Header: 'Join date' },
          { accessor: 'company_name', Header: 'Company name' },
          { accessor: 'first_name', Header: 'First name' },
          { accessor: 'last_name', Header: 'Last name' },
          { accessor: 'phone', Header: 'Phone' },
          { accessor: 'mobile', Header: 'Mobile' },
          { accessor: 'salary', Header: 'Salary' },
          { Header: 'Role', Cell: (props) => (props.original.role_id ? props.original.role_id.slug : undefined) },
          { accessor: 'email', Header: 'Email' },
          { accessor: 'encrypted_password', Header: 'Encrypted password' },
          { accessor: 'reset_password_token', Header: 'Reset password token' },
          { accessor: 'reset_password_sent_at', Header: 'Reset password sent at' },
          { accessor: 'remember_created_at', Header: 'Remember created at' },
          { accessor: 'sign_in_count', Header: 'Sign in count' },
          { accessor: 'current_sign_in_at', Header: 'Current sign in at' },
          { accessor: 'last_sign_in_at', Header: 'Last sign in at' },
          { accessor: 'current_sign_in_ip', Header: 'Current sign in ip' },
          { accessor: 'last_sign_in_ip', Header: 'Last sign in ip' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListAccounts;
