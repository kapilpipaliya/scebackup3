class CreateUserTaxRates < ActiveRecord::Migration[5.1]
  def change
    create_table :user_tax_rates do |t|
      t.belongs_to :user_tax_type, foreign_key: true
      t.integer :position
      t.string :slug
      t.decimal :rate, precision: 10, scale: 2

      t.timestamps
    end
    add_index :user_tax_rates, :position
    add_index :user_tax_rates, :slug, unique: true
  end
end
