import React from 'react';
import PropTypes from 'prop-types';

// import moment from 'moment';
import { FormControl, FormHelperText } from 'material-ui/Form';
import { DateTimePicker } from 'material-ui-pickers';

export default class MDateTimePicker extends React.Component {
  static propTypes = {
    input: PropTypes.object.isRequired,
    meta: PropTypes.object.isRequired,
    onChange2: PropTypes.func,
  }

  render() {
    const {
      // TODO Handle invalid or use react-dates library.
      // eslint-disable-next-line
      meta: {touched, error, invalid},
      input,
      onChange2,
    } = this.props;

    const inputChange = (e) => {
      input.onChange(e);
      if (onChange2) {
        onChange2(e);
      }
    };

    return (
      <FormControl>
        <DateTimePicker
          value={new Date(input.value)}
          onChange={inputChange}
          returnMoment
          format="DD/MM/YYYY HH:mm"
        />
        {touched &&
        error &&
        <FormHelperText>{error}</FormHelperText>}
      </FormControl>
    );
  }
}
