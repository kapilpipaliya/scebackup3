import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  gemType: gql`
    fragment GemTypeForEditingFragment on MaterialGemType {
      id
      position
      slug
      gem_type
      isdefault
    }
  `,
};

export default function (WrappedComponent) {
  const GET_GEM_TYPE = gql`
    query getGemType($id: ID) {
      gemType(id: $id) {
        ...GemTypeForEditingFragment
      }
    }
    ${fragments.gemType}
  `;

  const withGemTypeForEditing = graphql(GET_GEM_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withGemTypeForEditing(WrappedComponent);
}
