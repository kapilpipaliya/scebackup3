# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20171121082505) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "audits", force: :cascade do |t|
    t.integer "auditable_id"
    t.string "auditable_type"
    t.integer "associated_id"
    t.string "associated_type"
    t.integer "user_id"
    t.string "user_type"
    t.string "username"
    t.string "action"
    t.jsonb "audited_changes"
    t.integer "version", default: 0
    t.string "comment"
    t.string "remote_address"
    t.string "request_uuid"
    t.datetime "created_at"
    t.index ["associated_id", "associated_type"], name: "associated_index"
    t.index ["auditable_id", "auditable_type"], name: "auditable_index"
    t.index ["created_at"], name: "index_audits_on_created_at"
    t.index ["request_uuid"], name: "index_audits_on_request_uuid"
    t.index ["user_id", "user_type"], name: "user_index"
  end

  create_table "design_collection_hierarchies", id: false, force: :cascade do |t|
    t.integer "ancestor_id", null: false
    t.integer "descendant_id", null: false
    t.integer "generations", null: false
    t.index ["ancestor_id", "descendant_id", "generations"], name: "collection_anc_desc_idx", unique: true
    t.index ["descendant_id"], name: "collection_desc_idx"
  end

  create_table "design_collections", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "collection", null: false
    t.integer "parent_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["collection"], name: "index_design_collections_on_collection", unique: true
    t.index ["position"], name: "index_design_collections_on_position"
    t.index ["slug"], name: "index_design_collections_on_slug", unique: true
  end

  create_table "design_diamonds", force: :cascade do |t|
    t.integer "position"
    t.bigint "material_material_id", null: false
    t.bigint "material_gem_shape_id", null: false
    t.bigint "material_gem_clarity_id", null: false
    t.bigint "material_color_id"
    t.bigint "material_gem_size_id", null: false
    t.integer "pcs", default: 0, null: false
    t.decimal "pointer", precision: 10, scale: 3, default: "0.0", null: false
    t.decimal "weight", precision: 10, scale: 3, default: "0.0", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_color_id"], name: "index_design_diamonds_on_material_color_id"
    t.index ["material_gem_clarity_id"], name: "index_design_diamonds_on_material_gem_clarity_id"
    t.index ["material_gem_shape_id"], name: "index_design_diamonds_on_material_gem_shape_id"
    t.index ["material_gem_size_id"], name: "index_design_diamonds_on_material_gem_size_id"
    t.index ["material_material_id"], name: "index_design_diamonds_on_material_material_id"
    t.index ["position"], name: "index_design_diamonds_on_position"
  end

  create_table "design_images", force: :cascade do |t|
    t.string "imageable_type"
    t.bigint "imageable_id"
    t.string "image"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["imageable_type", "imageable_id"], name: "index_design_images_on_imageable_type_and_imageable_id"
  end

  create_table "design_job_diamonds", force: :cascade do |t|
    t.bigint "sale_job_id"
    t.bigint "design_diamond_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["design_diamond_id"], name: "index_design_job_diamonds_on_design_diamond_id"
    t.index ["sale_job_id"], name: "index_design_job_diamonds_on_sale_job_id"
  end

  create_table "design_making_types", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "making_type", null: false
    t.boolean "isdefault", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["making_type"], name: "index_design_making_types_on_making_type", unique: true
    t.index ["position"], name: "index_design_making_types_on_position"
    t.index ["slug"], name: "index_design_making_types_on_slug", unique: true
  end

  create_table "design_setting_types", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "setting_type", null: false
    t.boolean "isdefault", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_design_setting_types_on_position"
    t.index ["setting_type"], name: "index_design_setting_types_on_setting_type", unique: true
    t.index ["slug"], name: "index_design_setting_types_on_slug", unique: true
  end

  create_table "design_style_diamonds", force: :cascade do |t|
    t.bigint "design_style_id"
    t.bigint "design_diamond_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["design_diamond_id"], name: "index_design_style_diamonds_on_design_diamond_id"
    t.index ["design_style_id"], name: "index_design_style_diamonds_on_design_style_id"
  end

  create_table "design_style_transitions", force: :cascade do |t|
    t.string "to_state", null: false
    t.text "metadata", default: "{}"
    t.integer "sort_key", null: false
    t.bigint "design_style_id", null: false
    t.boolean "most_recent", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["design_style_id", "most_recent"], name: "index_design_style_transitions_parent_most_recent", unique: true, where: "most_recent"
    t.index ["design_style_id", "sort_key"], name: "index_design_style_transitions_parent_sort", unique: true
    t.index ["design_style_id"], name: "index_design_style_transitions_on_design_style_id"
  end

  create_table "design_styles", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.bigint "design_collection_id"
    t.bigint "design_making_type_id"
    t.bigint "design_setting_type_id"
    t.bigint "user_account_id"
    t.bigint "material_material_id"
    t.bigint "material_metal_purity_id"
    t.bigint "material_color_id"
    t.decimal "net_weight", precision: 10, scale: 3, null: false
    t.decimal "purity_per", precision: 10, scale: 3, default: "0.0"
    t.decimal "pure_weight", precision: 10, scale: 3, default: "0.0"
    t.decimal "volume", precision: 10, scale: 3, default: "0.0"
    t.integer "diamond_pcs", default: 0
    t.decimal "diamond_weight", precision: 10, scale: 3, default: "0.0"
    t.integer "cs_pcs", default: 0
    t.decimal "cs_weight", precision: 10, scale: 3, default: "0.0"
    t.decimal "gross_weight", precision: 10, scale: 3, default: "0.0"
    t.text "description"
    t.boolean "active", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["design_collection_id"], name: "index_design_styles_on_design_collection_id"
    t.index ["design_making_type_id"], name: "index_design_styles_on_design_making_type_id"
    t.index ["design_setting_type_id"], name: "index_design_styles_on_design_setting_type_id"
    t.index ["material_color_id"], name: "index_design_styles_on_material_color_id"
    t.index ["material_material_id"], name: "index_design_styles_on_material_material_id"
    t.index ["material_metal_purity_id"], name: "index_design_styles_on_material_metal_purity_id"
    t.index ["position"], name: "index_design_styles_on_position"
    t.index ["slug"], name: "index_design_styles_on_slug", unique: true
    t.index ["user_account_id"], name: "index_design_styles_on_user_account_id"
  end

  create_table "material_accessories", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "accessory", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["accessory"], name: "index_material_accessories_on_accessory", unique: true
    t.index ["position"], name: "index_material_accessories_on_position"
    t.index ["slug"], name: "index_material_accessories_on_slug", unique: true
  end

  create_table "material_colors", force: :cascade do |t|
    t.bigint "material_material_id", null: false
    t.integer "position"
    t.string "slug", null: false
    t.string "color", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_material_id"], name: "index_material_colors_on_material_material_id"
    t.index ["position"], name: "index_material_colors_on_position"
    t.index ["slug"], name: "index_material_colors_on_slug", unique: true
  end

  create_table "material_gem_clarities", force: :cascade do |t|
    t.bigint "material_material_id", null: false
    t.integer "position"
    t.string "slug", null: false
    t.string "clarity", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_material_id"], name: "index_material_gem_clarities_on_material_material_id"
    t.index ["position"], name: "index_material_gem_clarities_on_position"
    t.index ["slug"], name: "index_material_gem_clarities_on_slug", unique: true
  end

  create_table "material_gem_clarity_sizes", force: :cascade do |t|
    t.bigint "material_gem_clarity_id"
    t.bigint "material_gem_size_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_gem_clarity_id"], name: "index_material_gem_clarity_sizes_on_material_gem_clarity_id"
    t.index ["material_gem_size_id"], name: "index_material_gem_clarity_sizes_on_material_gem_size_id"
  end

  create_table "material_gem_shapes", force: :cascade do |t|
    t.bigint "material_material_id", null: false
    t.integer "position"
    t.string "slug", null: false
    t.string "shape", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_material_id"], name: "index_material_gem_shapes_on_material_material_id"
    t.index ["position"], name: "index_material_gem_shapes_on_position"
    t.index ["slug"], name: "index_material_gem_shapes_on_slug", unique: true
  end

  create_table "material_gem_sizes", force: :cascade do |t|
    t.bigint "material_material_id", null: false
    t.bigint "material_gem_shape_id", null: false
    t.integer "position"
    t.string "slug", null: false
    t.string "mm_size"
    t.decimal "carat_weight", precision: 10, scale: 3, null: false
    t.decimal "price", precision: 10, scale: 2
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_gem_shape_id"], name: "index_material_gem_sizes_on_material_gem_shape_id"
    t.index ["material_material_id"], name: "index_material_gem_sizes_on_material_material_id"
    t.index ["position"], name: "index_material_gem_sizes_on_position"
  end

  create_table "material_gem_types", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "gem_type", null: false
    t.boolean "isdefault", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["gem_type"], name: "index_material_gem_types_on_gem_type", unique: true
    t.index ["position"], name: "index_material_gem_types_on_position"
    t.index ["slug"], name: "index_material_gem_types_on_slug", unique: true
  end

  create_table "material_locations", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "location", null: false
    t.boolean "isdefault", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["location"], name: "index_material_locations_on_location", unique: true
    t.index ["position"], name: "index_material_locations_on_position"
    t.index ["slug"], name: "index_material_locations_on_slug", unique: true
  end

  create_table "material_lockers", force: :cascade do |t|
    t.bigint "material_location_id", null: false
    t.integer "position"
    t.string "slug", null: false
    t.string "locker", null: false
    t.boolean "isdefault", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["locker"], name: "index_material_lockers_on_locker", unique: true
    t.index ["material_location_id"], name: "index_material_lockers_on_material_location_id"
    t.index ["position"], name: "index_material_lockers_on_position"
    t.index ["slug"], name: "index_material_lockers_on_slug", unique: true
  end

  create_table "material_material_types", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "material_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_type"], name: "index_material_material_types_on_material_type", unique: true
    t.index ["position"], name: "index_material_material_types_on_position"
    t.index ["slug"], name: "index_material_material_types_on_slug", unique: true
  end

  create_table "material_materials", force: :cascade do |t|
    t.bigint "material_material_type_id", null: false
    t.integer "position"
    t.string "slug", null: false
    t.string "material_name", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_material_type_id"], name: "index_material_materials_on_material_material_type_id"
    t.index ["material_name"], name: "index_material_materials_on_material_name", unique: true
    t.index ["position"], name: "index_material_materials_on_position"
    t.index ["slug"], name: "index_material_materials_on_slug", unique: true
  end

  create_table "material_metal_purities", force: :cascade do |t|
    t.bigint "material_material_id", null: false
    t.integer "position"
    t.string "slug", null: false
    t.string "name", null: false
    t.decimal "purity", precision: 10, scale: 3, null: false
    t.decimal "specific_density", precision: 10, scale: 3, null: false
    t.decimal "price", precision: 10, scale: 2
    t.text "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_material_id"], name: "index_material_metal_purities_on_material_material_id"
    t.index ["position"], name: "index_material_metal_purities_on_position"
    t.index ["slug"], name: "index_material_metal_purities_on_slug", unique: true
  end

  create_table "material_rate_ons", force: :cascade do |t|
    t.bigint "material_material_type_id"
    t.integer "position"
    t.string "slug"
    t.string "rateon"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_material_type_id"], name: "index_material_rate_ons_on_material_material_type_id"
    t.index ["position"], name: "index_material_rate_ons_on_position"
    t.index ["rateon"], name: "index_material_rate_ons_on_rateon", unique: true
    t.index ["slug"], name: "index_material_rate_ons_on_slug", unique: true
  end

  create_table "mfg_casting_transitions", force: :cascade do |t|
    t.string "to_state", null: false
    t.text "metadata", default: "{}"
    t.integer "sort_key", null: false
    t.bigint "mfg_casting_id", null: false
    t.boolean "most_recent", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["mfg_casting_id", "most_recent"], name: "index_mfg_casting_transitions_parent_most_recent", unique: true, where: "most_recent"
    t.index ["mfg_casting_id", "sort_key"], name: "index_mfg_casting_transitions_parent_sort", unique: true
    t.index ["mfg_casting_id"], name: "index_mfg_casting_transitions_on_mfg_casting_id"
  end

  create_table "mfg_castings", force: :cascade do |t|
    t.integer "position"
    t.datetime "date", null: false
    t.string "slug", null: false
    t.bigint "employee_id"
    t.text "description"
    t.decimal "t_issue", precision: 10, scale: 3, default: "0.0"
    t.decimal "t_issue_pure", precision: 10, scale: 3, default: "0.0"
    t.decimal "t_rcv", precision: 10, scale: 3, default: "0.0"
    t.decimal "t_rcv_pure", precision: 10, scale: 3, default: "0.0"
    t.decimal "loss", precision: 10, scale: 3, default: "0.0"
    t.decimal "loss_pure", precision: 10, scale: 3, default: "0.0"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["employee_id"], name: "index_mfg_castings_on_employee_id"
    t.index ["position"], name: "index_mfg_castings_on_position"
  end

  create_table "mfg_department_hierarchies", id: false, force: :cascade do |t|
    t.integer "ancestor_id", null: false
    t.integer "descendant_id", null: false
    t.integer "generations", null: false
    t.index ["ancestor_id", "descendant_id", "generations"], name: "department_anc_desc_idx", unique: true
    t.index ["descendant_id"], name: "department_desc_idx"
  end

  create_table "mfg_departments", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "department", null: false
    t.integer "parent_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["department"], name: "index_mfg_departments_on_department", unique: true
    t.index ["position"], name: "index_mfg_departments_on_position"
    t.index ["slug"], name: "index_mfg_departments_on_slug", unique: true
  end

  create_table "mfg_dust_resources", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "dust_resource", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["dust_resource"], name: "index_mfg_dust_resources_on_dust_resource", unique: true
    t.index ["position"], name: "index_mfg_dust_resources_on_position"
    t.index ["slug"], name: "index_mfg_dust_resources_on_slug", unique: true
  end

  create_table "mfg_mfg_txns", force: :cascade do |t|
    t.integer "position"
    t.datetime "mfg_date", null: false
    t.bigint "mfg_casting_id"
    t.bigint "sale_job_id", null: false
    t.bigint "material_location_id", null: false
    t.string "department"
    t.bigint "user_account_id", null: false
    t.text "description"
    t.decimal "issue_weight", precision: 10, scale: 3, default: "0.0", null: false
    t.boolean "is_customer_stock", default: false, null: false
    t.integer "diamond_pcs", default: 0
    t.decimal "diamond_weight", precision: 10, scale: 3, default: "0.0"
    t.integer "cs_pcs", default: 0
    t.decimal "cs_weight", precision: 10, scale: 3, default: "0.0"
    t.decimal "t_issue", precision: 10, scale: 3, default: "0.0"
    t.decimal "t_issue_pure", precision: 10, scale: 3, default: "0.0"
    t.decimal "receive_weight", precision: 10, scale: 3, default: "0.0", null: false
    t.decimal "receive_pure_weight", precision: 10, scale: 3, default: "0.0", null: false
    t.decimal "final_receive_wt", precision: 10, scale: 3, default: "0.0", null: false
    t.boolean "received", default: false, null: false
    t.decimal "final_receive_pure_wt", precision: 10, scale: 3, default: "0.0", null: false
    t.decimal "dust_weight", precision: 10, scale: 3, default: "0.0"
    t.decimal "loss", precision: 10, scale: 3, default: "0.0"
    t.decimal "loss_pure", precision: 10, scale: 3, default: "0.0"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_location_id"], name: "index_mfg_mfg_txns_on_material_location_id"
    t.index ["mfg_casting_id"], name: "index_mfg_mfg_txns_on_mfg_casting_id"
    t.index ["position"], name: "index_mfg_mfg_txns_on_position"
    t.index ["sale_job_id"], name: "index_mfg_mfg_txns_on_sale_job_id"
    t.index ["user_account_id"], name: "index_mfg_mfg_txns_on_user_account_id"
  end

  create_table "mfg_priorities", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "priority", null: false
    t.boolean "isdefault", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_mfg_priorities_on_position"
    t.index ["priority"], name: "index_mfg_priorities_on_priority", unique: true
    t.index ["slug"], name: "index_mfg_priorities_on_slug", unique: true
  end

  create_table "mfg_product_types", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "product_type", null: false
    t.boolean "isdefault", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_mfg_product_types_on_position"
    t.index ["product_type"], name: "index_mfg_product_types_on_product_type", unique: true
    t.index ["slug"], name: "index_mfg_product_types_on_slug", unique: true
  end

  create_table "mfg_refinings", force: :cascade do |t|
    t.integer "position"
    t.bigint "user_account_id", null: false
    t.datetime "date_from", null: false
    t.datetime "date_to", null: false
    t.bigint "material_location_id", null: false
    t.bigint "mfg_department_id", null: false
    t.decimal "dust_weight", precision: 10, scale: 3, default: "0.0", null: false
    t.string "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["material_location_id"], name: "index_mfg_refinings_on_material_location_id"
    t.index ["mfg_department_id"], name: "index_mfg_refinings_on_mfg_department_id"
    t.index ["position"], name: "index_mfg_refinings_on_position"
    t.index ["user_account_id"], name: "index_mfg_refinings_on_user_account_id"
  end

  create_table "sale_job_transitions", force: :cascade do |t|
    t.string "to_state", null: false
    t.text "metadata", default: "{}"
    t.integer "sort_key", null: false
    t.bigint "sale_job_id", null: false
    t.boolean "most_recent", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["sale_job_id", "most_recent"], name: "index_sale_job_transitions_parent_most_recent", unique: true, where: "most_recent"
    t.index ["sale_job_id", "sort_key"], name: "index_sale_job_transitions_parent_sort", unique: true
    t.index ["sale_job_id"], name: "index_sale_job_transitions_on_sale_job_id"
  end

  create_table "sale_jobs", force: :cascade do |t|
    t.string "processable_type"
    t.bigint "processable_id"
    t.string "salable_type"
    t.bigint "salable_id"
    t.boolean "is_exist", default: false, null: false
    t.integer "position"
    t.bigint "design_style_id", null: false
    t.bigint "mfg_product_type_id", null: false
    t.bigint "material_location_id", null: false
    t.bigint "material_material_id", null: false
    t.bigint "metal_purity_id", null: false
    t.bigint "metal_color_id", null: false
    t.integer "qty", default: 1
    t.bigint "diamond_clarity_id"
    t.bigint "diamond_color_id"
    t.bigint "cs_clarity_id"
    t.bigint "cs_color_id"
    t.string "instruction"
    t.string "item_size"
    t.bigint "mfg_priority_id", null: false
    t.bigint "mfg_department_id"
    t.decimal "net_weight", precision: 10, scale: 3, default: "0.0"
    t.decimal "pure_weight", precision: 10, scale: 3, default: "0.0"
    t.integer "diamond_pcs", default: 0
    t.decimal "diamond_weight", precision: 10, scale: 3, default: "0.0"
    t.integer "cs_pcs", default: 0
    t.decimal "cs_weight", precision: 10, scale: 3, default: "0.0"
    t.decimal "gross_weight", precision: 10, scale: 3, default: "0.0"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["cs_clarity_id"], name: "index_sale_jobs_on_cs_clarity_id"
    t.index ["cs_color_id"], name: "index_sale_jobs_on_cs_color_id"
    t.index ["design_style_id"], name: "index_sale_jobs_on_design_style_id"
    t.index ["diamond_clarity_id"], name: "index_sale_jobs_on_diamond_clarity_id"
    t.index ["diamond_color_id"], name: "index_sale_jobs_on_diamond_color_id"
    t.index ["material_location_id"], name: "index_sale_jobs_on_material_location_id"
    t.index ["material_material_id"], name: "index_sale_jobs_on_material_material_id"
    t.index ["metal_color_id"], name: "index_sale_jobs_on_metal_color_id"
    t.index ["metal_purity_id"], name: "index_sale_jobs_on_metal_purity_id"
    t.index ["mfg_department_id"], name: "index_sale_jobs_on_mfg_department_id"
    t.index ["mfg_priority_id"], name: "index_sale_jobs_on_mfg_priority_id"
    t.index ["mfg_product_type_id"], name: "index_sale_jobs_on_mfg_product_type_id"
    t.index ["position"], name: "index_sale_jobs_on_position"
    t.index ["processable_type", "processable_id"], name: "index_sale_jobs_on_processable_type_and_processable_id"
    t.index ["salable_type", "salable_id"], name: "index_sale_jobs_on_salable_type_and_salable_id"
  end

  create_table "sale_m_txn_details", force: :cascade do |t|
    t.string "countable_type"
    t.bigint "countable_id"
    t.string "countable_r_type"
    t.bigint "countable_r_id"
    t.integer "position"
    t.bigint "material_material_id"
    t.bigint "material_metal_purity_id"
    t.bigint "material_gem_shape_id"
    t.bigint "material_gem_clarity_id"
    t.bigint "material_color_id"
    t.bigint "material_gem_size_id"
    t.bigint "material_location_id"
    t.bigint "material_locker_id"
    t.bigint "material_accessory_id"
    t.boolean "customer_stock", default: false, null: false
    t.boolean "isissue", default: true, null: false
    t.integer "pcs", default: 0
    t.decimal "weight1", precision: 10, scale: 3, default: "0.0"
    t.decimal "purity_per", precision: 10, scale: 3, default: "0.0"
    t.decimal "pure_weight", precision: 10, scale: 3, default: "0.0"
    t.string "note"
    t.bigint "material_gem_type_id"
    t.boolean "rate_on_pc", default: false, null: false
    t.decimal "rate1", precision: 10, scale: 3, default: "0.0"
    t.decimal "amount", precision: 10, scale: 2, default: "0.0"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["countable_r_type", "countable_r_id"], name: "index_sale_m_txn_details_on_countable_r_type_and_countable_r_id"
    t.index ["countable_type", "countable_id"], name: "index_sale_m_txn_details_on_countable_type_and_countable_id"
    t.index ["material_accessory_id"], name: "index_sale_m_txn_details_on_material_accessory_id"
    t.index ["material_color_id"], name: "index_sale_m_txn_details_on_material_color_id"
    t.index ["material_gem_clarity_id"], name: "index_sale_m_txn_details_on_material_gem_clarity_id"
    t.index ["material_gem_shape_id"], name: "index_sale_m_txn_details_on_material_gem_shape_id"
    t.index ["material_gem_size_id"], name: "index_sale_m_txn_details_on_material_gem_size_id"
    t.index ["material_gem_type_id"], name: "index_sale_m_txn_details_on_material_gem_type_id"
    t.index ["material_location_id"], name: "index_sale_m_txn_details_on_material_location_id"
    t.index ["material_locker_id"], name: "index_sale_m_txn_details_on_material_locker_id"
    t.index ["material_material_id"], name: "index_sale_m_txn_details_on_material_material_id"
    t.index ["material_metal_purity_id"], name: "index_sale_m_txn_details_on_material_metal_purity_id"
    t.index ["position"], name: "index_sale_m_txn_details_on_position"
  end

  create_table "sale_m_txn_transitions", force: :cascade do |t|
    t.string "to_state", null: false
    t.text "metadata", default: "{}"
    t.integer "sort_key", null: false
    t.bigint "sale_m_txn_id", null: false
    t.boolean "most_recent", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["sale_m_txn_id", "most_recent"], name: "index_sale_m_txn_transitions_parent_most_recent", unique: true, where: "most_recent"
    t.index ["sale_m_txn_id", "sort_key"], name: "index_sale_m_txn_transitions_parent_sort", unique: true
    t.index ["sale_m_txn_id"], name: "index_sale_m_txn_transitions_on_sale_m_txn_id"
  end

  create_table "sale_m_txn_types", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "txn_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_sale_m_txn_types_on_position"
    t.index ["slug"], name: "index_sale_m_txn_types_on_slug", unique: true
  end

  create_table "sale_m_txns", force: :cascade do |t|
    t.integer "position"
    t.bigint "sale_m_txn_type_id", null: false
    t.bigint "user_account_id", null: false
    t.bigint "taken_by_id", null: false
    t.datetime "date", null: false
    t.datetime "due_date", null: false
    t.decimal "total_weight", precision: 10, scale: 3, null: false
    t.decimal "amount", precision: 10, scale: 2, null: false
    t.text "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_sale_m_txns_on_position"
    t.index ["sale_m_txn_type_id"], name: "index_sale_m_txns_on_sale_m_txn_type_id"
    t.index ["taken_by_id"], name: "index_sale_m_txns_on_taken_by_id"
    t.index ["user_account_id"], name: "index_sale_m_txns_on_user_account_id"
  end

  create_table "sale_memos", force: :cascade do |t|
    t.integer "position"
    t.datetime "date", null: false
    t.text "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_sale_memos_on_position"
  end

  create_table "sale_order_transitions", force: :cascade do |t|
    t.string "to_state", null: false
    t.text "metadata", default: "{}"
    t.integer "sort_key", null: false
    t.bigint "sale_order_id", null: false
    t.boolean "most_recent", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["sale_order_id", "most_recent"], name: "index_sale_order_transitions_parent_most_recent", unique: true, where: "most_recent"
    t.index ["sale_order_id", "sort_key"], name: "index_sale_order_transitions_parent_sort", unique: true
    t.index ["sale_order_id"], name: "index_sale_order_transitions_on_sale_order_id"
  end

  create_table "sale_order_types", force: :cascade do |t|
    t.integer "position"
    t.string "slug", null: false
    t.string "order_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["order_type"], name: "index_sale_order_types_on_order_type", unique: true
    t.index ["position"], name: "index_sale_order_types_on_position"
    t.index ["slug"], name: "index_sale_order_types_on_slug", unique: true
  end

  create_table "sale_orders", force: :cascade do |t|
    t.integer "position"
    t.bigint "customer_id", null: false
    t.bigint "taken_by_id", null: false
    t.datetime "order_date", null: false
    t.datetime "delivery_date", null: false
    t.bigint "mfg_product_type_id"
    t.text "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["customer_id"], name: "index_sale_orders_on_customer_id"
    t.index ["mfg_product_type_id"], name: "index_sale_orders_on_mfg_product_type_id"
    t.index ["position"], name: "index_sale_orders_on_position"
    t.index ["taken_by_id"], name: "index_sale_orders_on_taken_by_id"
  end

  create_table "sale_sale_details", force: :cascade do |t|
    t.string "saleable_type"
    t.bigint "saleable_id"
    t.integer "position"
    t.decimal "tounch", precision: 10, scale: 3, default: "0.0"
    t.bigint "m_rate_on_id"
    t.decimal "m_rate", precision: 10, scale: 3, default: "0.0"
    t.decimal "m_amount", precision: 10, scale: 3, default: "0.0"
    t.bigint "d_rate_on_id"
    t.decimal "d_rate", precision: 10, scale: 3, default: "0.0"
    t.decimal "d_amount", precision: 10, scale: 3, default: "0.0"
    t.bigint "cs_rate_on_id"
    t.decimal "cs_rate", precision: 10, scale: 3, default: "0.0"
    t.decimal "cs_amount", precision: 10, scale: 3, default: "0.0"
    t.decimal "total_amount", precision: 10, scale: 3, default: "0.0"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["cs_rate_on_id"], name: "index_sale_sale_details_on_cs_rate_on_id"
    t.index ["d_rate_on_id"], name: "index_sale_sale_details_on_d_rate_on_id"
    t.index ["m_rate_on_id"], name: "index_sale_sale_details_on_m_rate_on_id"
    t.index ["position"], name: "index_sale_sale_details_on_position"
    t.index ["saleable_type", "saleable_id"], name: "index_sale_sale_details_on_saleable_type_and_saleable_id"
  end

  create_table "sale_sales", force: :cascade do |t|
    t.integer "position"
    t.bigint "customer_id", null: false
    t.bigint "sold_by_id", null: false
    t.datetime "date", null: false
    t.datetime "due_date", null: false
    t.text "description"
    t.decimal "net_weight", precision: 10, scale: 3, default: "0.0"
    t.decimal "pure_weight", precision: 10, scale: 3, default: "0.0"
    t.integer "diamond_pcs", default: 0
    t.decimal "diamond_weight", precision: 10, scale: 3, default: "0.0"
    t.integer "cs_pcs", default: 0
    t.decimal "cs_weight", precision: 10, scale: 3, default: "0.0"
    t.decimal "gross_weight", precision: 10, scale: 3, default: "0.0"
    t.decimal "tax", precision: 10, scale: 3, default: "0.0"
    t.decimal "discount", precision: 10, scale: 3, default: "0.0"
    t.decimal "amount", precision: 10, scale: 2, default: "0.0"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["customer_id"], name: "index_sale_sales_on_customer_id"
    t.index ["position"], name: "index_sale_sales_on_position"
    t.index ["sold_by_id"], name: "index_sale_sales_on_sold_by_id"
  end

  create_table "user_account_transitions", force: :cascade do |t|
    t.string "to_state", null: false
    t.text "metadata", default: "{}"
    t.integer "sort_key", null: false
    t.bigint "user_account_id", null: false
    t.boolean "most_recent", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_account_id", "most_recent"], name: "index_user_account_transitions_parent_most_recent", unique: true, where: "most_recent"
    t.index ["user_account_id", "sort_key"], name: "index_user_account_transitions_parent_sort", unique: true
    t.index ["user_account_id"], name: "index_user_account_transitions_on_user_account_id"
  end

  create_table "user_account_types", force: :cascade do |t|
    t.integer "position"
    t.string "slug"
    t.string "account_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["account_type"], name: "index_user_account_types_on_account_type", unique: true
    t.index ["position"], name: "index_user_account_types_on_position"
    t.index ["slug"], name: "index_user_account_types_on_slug", unique: true
  end

  create_table "user_accounts", force: :cascade do |t|
    t.bigint "user_account_type_id", null: false
    t.integer "position"
    t.string "slug", null: false
    t.date "join_date"
    t.string "company_name", null: false
    t.string "first_name", null: false
    t.string "last_name", null: false
    t.string "phone"
    t.string "mobile", null: false
    t.integer "salary", default: 0
    t.bigint "user_role_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer "sign_in_count", default: 0, null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet "current_sign_in_ip"
    t.inet "last_sign_in_ip"
    t.index ["company_name"], name: "index_user_accounts_on_company_name", unique: true
    t.index ["email"], name: "index_user_accounts_on_email", unique: true
    t.index ["position"], name: "index_user_accounts_on_position"
    t.index ["reset_password_token"], name: "index_user_accounts_on_reset_password_token", unique: true
    t.index ["slug"], name: "index_user_accounts_on_slug", unique: true
    t.index ["user_account_type_id"], name: "index_user_accounts_on_user_account_type_id"
    t.index ["user_role_id"], name: "index_user_accounts_on_user_role_id"
  end

  create_table "user_addresses", force: :cascade do |t|
    t.bigint "user_account_id", null: false
    t.integer "position"
    t.string "firstname"
    t.string "lastname"
    t.string "address1"
    t.string "address2"
    t.string "city"
    t.string "zipcode"
    t.bigint "user_state_id"
    t.bigint "user_country_id"
    t.string "phone"
    t.string "alternative_phone"
    t.string "company"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_user_addresses_on_position"
    t.index ["user_account_id"], name: "index_user_addresses_on_user_account_id"
    t.index ["user_country_id"], name: "index_user_addresses_on_user_country_id"
    t.index ["user_state_id"], name: "index_user_addresses_on_user_state_id"
  end

  create_table "user_companies", force: :cascade do |t|
    t.bigint "user_contact_id"
    t.integer "position"
    t.string "slug"
    t.string "company"
    t.string "name"
    t.string "email"
    t.string "address"
    t.string "gst_no"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["company"], name: "index_user_companies_on_company", unique: true
    t.index ["position"], name: "index_user_companies_on_position"
    t.index ["slug"], name: "index_user_companies_on_slug", unique: true
    t.index ["user_contact_id"], name: "index_user_companies_on_user_contact_id"
  end

  create_table "user_company_ownerships", force: :cascade do |t|
    t.bigint "user_company_id"
    t.bigint "user_account_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_account_id"], name: "index_user_company_ownerships_on_user_account_id"
    t.index ["user_company_id"], name: "index_user_company_ownerships_on_user_company_id"
  end

  create_table "user_contacts", force: :cascade do |t|
    t.integer "position"
    t.string "slug"
    t.string "first_name"
    t.string "last_name"
    t.string "email"
    t.string "phone"
    t.string "mobile"
    t.integer "salary", default: 0
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["email"], name: "index_user_contacts_on_email", unique: true
    t.index ["position"], name: "index_user_contacts_on_position"
    t.index ["slug"], name: "index_user_contacts_on_slug", unique: true
  end

  create_table "user_countries", force: :cascade do |t|
    t.integer "position"
    t.string "slug"
    t.string "country"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_user_countries_on_position"
    t.index ["slug"], name: "index_user_countries_on_slug", unique: true
  end

  create_table "user_roles", force: :cascade do |t|
    t.integer "position"
    t.string "slug"
    t.string "role"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_user_roles_on_position"
    t.index ["role"], name: "index_user_roles_on_role", unique: true
    t.index ["slug"], name: "index_user_roles_on_slug", unique: true
  end

  create_table "user_states", force: :cascade do |t|
    t.integer "position"
    t.bigint "user_country_id"
    t.string "slug"
    t.string "state"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_user_states_on_position"
    t.index ["slug"], name: "index_user_states_on_slug", unique: true
    t.index ["user_country_id"], name: "index_user_states_on_user_country_id"
  end

  create_table "user_tax_rates", force: :cascade do |t|
    t.bigint "user_tax_type_id"
    t.integer "position"
    t.string "slug"
    t.decimal "rate", precision: 10, scale: 2
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_user_tax_rates_on_position"
    t.index ["slug"], name: "index_user_tax_rates_on_slug", unique: true
    t.index ["user_tax_type_id"], name: "index_user_tax_rates_on_user_tax_type_id"
  end

  create_table "user_tax_types", force: :cascade do |t|
    t.integer "position"
    t.string "slug"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["position"], name: "index_user_tax_types_on_position"
    t.index ["slug"], name: "index_user_tax_types_on_slug", unique: true
  end

  add_foreign_key "design_diamonds", "material_colors"
  add_foreign_key "design_diamonds", "material_gem_clarities"
  add_foreign_key "design_diamonds", "material_gem_shapes"
  add_foreign_key "design_diamonds", "material_gem_sizes"
  add_foreign_key "design_diamonds", "material_materials"
  add_foreign_key "design_job_diamonds", "design_diamonds"
  add_foreign_key "design_job_diamonds", "sale_jobs"
  add_foreign_key "design_style_diamonds", "design_diamonds"
  add_foreign_key "design_style_diamonds", "design_styles"
  add_foreign_key "design_style_transitions", "design_styles"
  add_foreign_key "design_styles", "design_collections"
  add_foreign_key "design_styles", "design_making_types"
  add_foreign_key "design_styles", "design_setting_types"
  add_foreign_key "design_styles", "material_colors"
  add_foreign_key "design_styles", "material_materials"
  add_foreign_key "design_styles", "material_metal_purities"
  add_foreign_key "design_styles", "user_accounts"
  add_foreign_key "material_colors", "material_materials"
  add_foreign_key "material_gem_clarities", "material_materials"
  add_foreign_key "material_gem_clarity_sizes", "material_gem_clarities"
  add_foreign_key "material_gem_clarity_sizes", "material_gem_sizes"
  add_foreign_key "material_gem_shapes", "material_materials"
  add_foreign_key "material_gem_sizes", "material_gem_shapes"
  add_foreign_key "material_gem_sizes", "material_materials"
  add_foreign_key "material_lockers", "material_locations"
  add_foreign_key "material_materials", "material_material_types"
  add_foreign_key "material_metal_purities", "material_materials"
  add_foreign_key "material_rate_ons", "material_material_types"
  add_foreign_key "mfg_casting_transitions", "mfg_castings"
  add_foreign_key "mfg_castings", "user_accounts", column: "employee_id"
  add_foreign_key "mfg_mfg_txns", "material_locations"
  add_foreign_key "mfg_mfg_txns", "mfg_castings"
  add_foreign_key "mfg_mfg_txns", "sale_jobs"
  add_foreign_key "mfg_mfg_txns", "user_accounts"
  add_foreign_key "mfg_refinings", "material_locations"
  add_foreign_key "mfg_refinings", "mfg_departments"
  add_foreign_key "mfg_refinings", "user_accounts"
  add_foreign_key "sale_job_transitions", "sale_jobs"
  add_foreign_key "sale_jobs", "design_styles"
  add_foreign_key "sale_jobs", "material_colors", column: "cs_color_id"
  add_foreign_key "sale_jobs", "material_colors", column: "diamond_color_id"
  add_foreign_key "sale_jobs", "material_colors", column: "metal_color_id"
  add_foreign_key "sale_jobs", "material_gem_clarities", column: "cs_clarity_id"
  add_foreign_key "sale_jobs", "material_gem_clarities", column: "diamond_clarity_id"
  add_foreign_key "sale_jobs", "material_locations"
  add_foreign_key "sale_jobs", "material_materials"
  add_foreign_key "sale_jobs", "material_metal_purities", column: "metal_purity_id"
  add_foreign_key "sale_jobs", "mfg_departments"
  add_foreign_key "sale_jobs", "mfg_priorities"
  add_foreign_key "sale_jobs", "mfg_product_types"
  add_foreign_key "sale_m_txn_details", "material_accessories"
  add_foreign_key "sale_m_txn_details", "material_colors"
  add_foreign_key "sale_m_txn_details", "material_gem_clarities"
  add_foreign_key "sale_m_txn_details", "material_gem_shapes"
  add_foreign_key "sale_m_txn_details", "material_gem_sizes"
  add_foreign_key "sale_m_txn_details", "material_gem_types"
  add_foreign_key "sale_m_txn_details", "material_locations"
  add_foreign_key "sale_m_txn_details", "material_lockers"
  add_foreign_key "sale_m_txn_details", "material_materials"
  add_foreign_key "sale_m_txn_details", "material_metal_purities"
  add_foreign_key "sale_m_txn_transitions", "sale_m_txns"
  add_foreign_key "sale_m_txns", "sale_m_txn_types"
  add_foreign_key "sale_m_txns", "user_accounts"
  add_foreign_key "sale_m_txns", "user_accounts", column: "taken_by_id"
  add_foreign_key "sale_order_transitions", "sale_orders"
  add_foreign_key "sale_orders", "mfg_product_types"
  add_foreign_key "sale_orders", "user_accounts", column: "customer_id"
  add_foreign_key "sale_orders", "user_accounts", column: "taken_by_id"
  add_foreign_key "sale_sales", "user_accounts", column: "customer_id"
  add_foreign_key "sale_sales", "user_accounts", column: "sold_by_id"
  add_foreign_key "user_account_transitions", "user_accounts"
  add_foreign_key "user_accounts", "user_account_types"
  add_foreign_key "user_accounts", "user_roles"
  add_foreign_key "user_addresses", "user_accounts"
  add_foreign_key "user_addresses", "user_countries"
  add_foreign_key "user_addresses", "user_states"
  add_foreign_key "user_companies", "user_contacts"
  add_foreign_key "user_company_ownerships", "user_accounts"
  add_foreign_key "user_company_ownerships", "user_companies"
  add_foreign_key "user_states", "user_countries"
  add_foreign_key "user_tax_rates", "user_tax_types"
end
