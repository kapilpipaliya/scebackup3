import React from 'react';
import { observer } from 'mobx-react';
import _ from 'lodash';
import Grid from 'material-ui/Grid';
import { withApollo } from 'react-apollo';
import FormControls from '../../../components/controls/FormControls';
import MaterialTextField from '../../../components/inputs/MaterialTextField';
import NumberInput from '../../../components/inputs/NumberInput';
import SimpleSelectMaterial from '../../../components/inputs/SimpleSelectMaterial';

import { AllTaxTypesQuery } from '../../../queries/user/tax_types/taxTypesQuery';
// Part1
// Part1

@withApollo
@observer
class Form extends React.Component {
  componentDidMount() {
    this._componenDidMount();
  }
  async _componenDidMount() {
    this.fetchTaxTypes('user_tax_type_id', 1)
  }

  fetchTaxTypes = async (field ) => {
    const taxTypes = await this.props.client.query({
      query: AllTaxTypesQuery,
      variables: {},
    });
    this.props.form.set('extra', {
      [field]: _.mapKeys(taxTypes.data.allUserTaxTypes, (value) => value.id)
    })
  }
// Part2
// Part2

  render(){
  
  const {form, action} = this.props;
  
  // if(this.props.initialValues) {
  //   form.set('value', this.props.initialValues)
  // }
  
  const hooks = {
    onSuccess(form) {
      // alert('submitting....');

      return action(form.values()).then((errors) => {
        if (errors) {
          form.set('error', errors);
          
          Object.keys(errors).forEach((v) => {
            form.$(v).invalidate(errors[v])
          });
          // form.invalidate('This is a generic error message!');
          
        } else {
          form.clear()
        }
      })
    }
  }
    
  return(
    <form>
      <fieldset>
        <Grid container spacing={24}>
          <Grid item xs={12}><SimpleSelectMaterial field={form.$('user_tax_type_id')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('position')} /></Grid>
          <Grid item xs={12}><MaterialTextField field={form.$('slug')} /></Grid>
          <Grid item xs={12}><NumberInput field={form.$('rate')} inputProps={{decimalScale:'3', fixedDecimalScale: true}} /></Grid>
        </Grid>
        <FormControls form={form} hooks={hooks}/>
      </fieldset>
    </form>
  )}
}

export default Form;
