import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  location: gql`
    fragment LocationForEditingFragment on MaterialLocation {
      id
      position
      slug
      location
      isdefault
    }
  `,
};

export default function (WrappedComponent) {
  const GET_LOCATION = gql`
    query getLocation($id: ID) {
      location(id: $id) {
        ...LocationForEditingFragment
      }
    }
    ${fragments.location}
  `;

  const withLocationForEditing = graphql(GET_LOCATION, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withLocationForEditing(WrappedComponent);
}
