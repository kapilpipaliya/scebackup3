import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import StateForm from './_StateForm';
import withStateForEditing from '../../../queries/user/states/stateForEditingQuery';
import withUpdateState from '../../../mutations/user/states/updateStateMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditState extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { state, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing state</h1>
        <StateForm action={this.props.updateState} initialValues={{ ...flatIDValue(state) }} submitName="Update State" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withStateForEditing(withUpdateState(EditState));
