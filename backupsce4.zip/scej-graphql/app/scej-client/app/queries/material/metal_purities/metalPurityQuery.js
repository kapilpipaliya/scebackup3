import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  metalPurity: gql`
    fragment MetalPurityFragment on MaterialMetalPurity {
      id
      material_id { id slug }
      position
      slug
      name
      purity
      specific_density
      price
      description
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_METAL_PURITY = gql`
    query getMetalPurity($id: ID) {
      metalPurity(id: $id) {
        ...MetalPurityFragment
      }
    }
    ${fragments.metalPurity}
  `;

  const withMetalPurity = graphql(GET_METAL_PURITY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMetalPurity(WrappedComponent);
}
