
import validatorjs from 'validatorjs';

export default {
  plugins: { dvr: validatorjs },
  options: {
  },
  fields: [
  "position",
  "slug",
  "account_type"
],
  initials: {
},
  labels: {
  "position": "SN#",
  "slug": "Code",
  "account_type": "Account type"
},
  placeholders: {
  "position": "Position",
  "slug": "Slug",
  "account_type": "Account type"
},
  types: {
  "position": "number",
  "slug": "text",
  "account_type": "text"
},
  rules: {
  "position": "",
  "slug": "",
  "account_type": ""
},
  hooks: {
    onSuccess(form) {
      alert('Form is valid! Send the request here.');
      // get field values
      console.log('Form Values!', form.values());
    },
    onError(form) {
      alert('Form has errors!');
      // get all form errors
      console.log('All form errors', form.errors());
    }
  },
  bindings: {
}
}
