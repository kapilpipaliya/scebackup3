class CreateMaterialLocations < ActiveRecord::Migration[5.1]
  def change
    create_table :material_locations do |t|
      t.integer :position
      t.string :slug, null: false
      t.string :location, null: false
      t.boolean :isdefault, null: false, default:false

      t.timestamps
    end
    add_index :material_locations, :position
    add_index :material_locations, :slug, unique: true
    add_index :material_locations, :location, unique: true
  end
end
