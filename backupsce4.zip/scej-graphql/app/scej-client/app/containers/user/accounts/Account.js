import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withAccount from '../../../queries/user/accounts/accountQuery';

class Account extends Component {
  render() {
    const { account, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="account">
        <p>Account</p>
        <h2 className="account-heading">{account.slug}</h2>
        <div className="account-meta">
          <span className="account-author">
            Posted by: <em>{/* {account.author.name} */}</em>
          </span>
          <span className="account-date">
            {moment(new Date(account.created_at)).fromNow()}
          </span>
        </div>
        <div className="account-content">
          contents display here: ID : {account.id}
        </div>
      </article>
    );
  }
}

export default withAccount(Account);
