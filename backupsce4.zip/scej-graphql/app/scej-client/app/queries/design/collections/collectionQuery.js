import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  collection: gql`
    fragment CollectionFragment on DesignCollection {
      id
      position
      slug
      collection
      parent_id { id slug }
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_COLLECTION = gql`
    query getCollection($id: ID) {
      collection(id: $id) {
        ...CollectionFragment
      }
    }
    ${fragments.collection}
  `;

  const withCollection = graphql(GET_COLLECTION, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withCollection(WrappedComponent);
}
