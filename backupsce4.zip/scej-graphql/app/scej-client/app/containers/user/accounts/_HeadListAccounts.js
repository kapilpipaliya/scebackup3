import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
import AddIcon from 'material-ui-icons/Add';

import SearchAccountForm from './_SearchAccountForm';
import withCurrentUser from '../../../queries/users/currentUserQuery';


const styles = (theme) => ({
  button: {
    margin: theme.spacing.unit,
  },
});

@withStyles(styles)
class ListAccounts extends Component {
  render() {
    const { keywords, searchLoading, currentUser } = this.props;
    const { classes } = this.props;

    return (
      <div>
        <div>
          <SearchAccountForm initialKeywords={keywords} loading={searchLoading} />
        </div>
        {currentUser ? (
          <div>
            <Link to="/accounts/new">
              <Button fab color="primary" aria-label="add" className={classes.button}><AddIcon /></Button>
            </Link>
          </div>
        ) : null}
      </div>
    );
  }
}

export default withCurrentUser(ListAccounts);
