import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withAccountTypesData from '../../../queries/user/account_types/accountTypesQuery';

import ListAccountTypes from './_ListAccountTypes';
import HeadListAccountTypes from './_HeadListAccountTypes';

class AllAccountTypes extends Component {
  componentDidMount() {
    this.props.accounttypes.refetch(); // You can pass variables here.
  }

  render() {
    const { accounttypes: { loading, error }, accounttypes } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListAccountTypes />
        <ListAccountTypes data={accounttypes} />
      </div>
    );
  }
}

export default withAccountTypesData(AllAccountTypes);
