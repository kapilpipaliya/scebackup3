import React, { Component } from 'react';

import { reduxForm, SubmissionError } from 'redux-form/immutable';
import Button from 'material-ui/Button';

import { Position, Slug, FirstName, LastName, Email, Phone, Mobile, Salary } from './_ContactFields'; // eslint-disable-line no-unused-vars

class ContactForm extends Component {
   state = { loading: false };

  submitForm = (values) => {
    this.setState({ loading: true });
    return this.props.action(values).then((errors) => {
      if (errors) {
        this.setState({ loading: false });
        throw new SubmissionError(errors);
      }
    });
  }

  render() {
    const {
      handleSubmit, pristine, reset, invalid, submitting, submitName,
    } = this.props;
    const { loading } = this.state;

    return (
      <form onSubmit={handleSubmit(this.submitForm)}>
        <fieldset>
          {/* <legend></legend> */}
          <Position label="Position(optional)" />
          <Slug />
          <FirstName />
          <LastName />
          <Email />
          <Phone />
          <Mobile />
          <Salary />
          <Button raised type="submit" disabled={loading || invalid || submitting}>{submitName}</Button>
          <Button raised disabled={loading || pristine || submitting} onClick={reset} style={{ margin: '5px' }}>Clear Values</Button>
        </fieldset>
      </form>
    );
  }
}

function validate(values) {
  const errors = {};
  if (!values.get('slug')) {
    errors.slug = "can't be blank";
  }
  if (!values.get('first_name')) {
    errors.first_name = "can't be blank";
  }
  return errors;
}

export default reduxForm({
  form: 'ContactForm',
  validate,
})(ContactForm);
