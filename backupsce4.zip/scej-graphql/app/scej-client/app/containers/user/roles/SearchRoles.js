import React, { Component } from 'react';
import ListRoles from './_ListRoles';
import HeadListRoles from './_HeadListRoles';
import withRolesData from '../../../queries/user/roles/rolesQuery';

class SearchRoles extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.roles = [];
    }
  }

  render() {
    const { roles, rolesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreRoles,
      firstRolesLoading,
    } = this.props;

    return (
      <div className="search-roles">
        <h1>Searching roles</h1>
        <HeadListRoles
          initialKeywords={keywords}
          loading={firstRolesLoading}
        />

        {!firstRolesLoading && roles && roles.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListRoles
            roles={roles}
            rolesCount={rolesCount}
            loading={loading}
            loadMoreRoles={loadMoreRoles}
          />
        )}
      </div>
    );
  }
}

export default withRolesData(SearchRoles);
