import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  contact: gql`
    fragment ContactFragment on UserContact {
      id
      position
      slug
      first_name
      last_name
      email
      phone
      mobile
      salary
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_CONTACT = gql`
    query getContact($id: ID) {
      contact(id: $id) {
        ...ContactFragment
      }
    }
    ${fragments.contact}
  `;

  const withContact = graphql(GET_CONTACT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withContact(WrappedComponent);
}
