import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  country: gql`
    fragment CountryPreviewFragment on UserCountry {
      id
      position
      slug
      country
      created_at
    }
  `,
};

export const AllCountriesQuery = gql`
  query allUserCountriesQuery {
    countriesCount
    allUserCountries {
      ...CountryPreviewFragment
    }
  }
  ${fragments.country}
`;

export default graphql(AllCountriesQuery, {
  name: 'countries',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
