import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  casting: gql`
    fragment CastingFragment on MfgCasting {
      id
      position
      date
      slug
      employee_id { id slug }
      description
      t_issue
      t_issue_pure
      t_rcv
      t_rcv_pure
      loss
      loss_pure
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_CASTING = gql`
    query getCasting($id: ID) {
      casting(id: $id) {
        ...CastingFragment
      }
    }
    ${fragments.casting}
  `;

  const withCasting = graphql(GET_CASTING, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withCasting(WrappedComponent);
}
