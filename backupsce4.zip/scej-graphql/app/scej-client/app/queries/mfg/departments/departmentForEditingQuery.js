import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  department: gql`
    fragment DepartmentForEditingFragment on MfgDepartment {
      id
      position
      slug
      department
      parent_id { id slug }
    }
  `,
};

export default function (WrappedComponent) {
  const GET_DEPARTMENT = gql`
    query getDepartment($id: ID) {
      department(id: $id) {
        ...DepartmentForEditingFragment
      }
    }
    ${fragments.department}
  `;

  const withDepartmentForEditing = graphql(GET_DEPARTMENT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withDepartmentForEditing(WrappedComponent);
}
