import React, { Component } from 'react';
import Button from 'material-ui/Button';
import TaxRateForm from './_TaxRateForm';
import withCreateTaxRate from '../../../mutations/user/tax_rates/createTaxRateMutation';

class NewTaxRate extends Component {
  render() {
    return (
      <div>
        <h1>New TaxRate</h1>
        <TaxRateForm action={this.props.createTaxRate} submitName="Create TaxRate" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateTaxRate(NewTaxRate);
