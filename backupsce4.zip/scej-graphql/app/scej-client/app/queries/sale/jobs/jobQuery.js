import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  job: gql`
    fragment JobFragment on SaleJob {
      id
      processable_type
      processable_id { id slug }
      salable_type
      salable_id { id slug }
      is_exist
      position
      style_id { id slug }
      product_type_id { id slug }
      location_id { id slug }
      material_id { id slug }
      metal_purity_id { id slug }
      metal_color_id { id slug }
      qty
      diamond_clarity_id { id slug }
      diamond_color_id { id slug }
      cs_clarity_id { id slug }
      cs_color_id { id slug }
      instruction
      item_size
      priority_id { id slug }
      department_id { id slug }
      net_weight
      pure_weight
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_JOB = gql`
    query getJob($id: ID) {
      job(id: $id) {
        ...JobFragment
      }
    }
    ${fragments.job}
  `;

  const withJob = graphql(GET_JOB, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withJob(WrappedComponent);
}
