class AllmodelsGenerator < Rails::Generators::NamedBase
  source_root File.expand_path('../templates', __FILE__)

  def generate_query_type
    template 'query_type.rb.erb', "app/graphql/types/query_type.rb"
  end
  
  private
  
  def allModels
      modelNames = ApplicationRecord.descendants.map do |a| a.model_name.name end
      modelNames.sort
  end
  
  def save_variabls(n)
    @f = n.deconstantize.freeze
    @l = n.demodulize.freeze
    @fD = @f.downcase.freeze
    @fUD = @f.underscore.downcase.freeze
    @dP = @l.downcase.pluralize.freeze
    @CP = @l.camelize.pluralize.freeze
    @cP = @l.camelize(:lower).pluralize.freeze
    @UP = @l.underscore.pluralize.freeze
    @UDP = @l.underscore.downcase.pluralize.freeze
    @UUS = @l.singularize.underscore.upcase.freeze
    @UDS = @l.singularize.underscore.downcase.freeze
    @CS = @l.singularize.camelize.freeze
    @cS = @l.singularize.camelize(:lower).freeze
    @client = 'app/scej-client'
    if options.path
      if options.path === 'tmp'
        @clientSrc = "#{@client}/tmp"
      else
        @clientSrc = options.path
      end
    else
      @clientSrc = "#{@client}/app"
    end
  end
  
  def query_arguments
    arguments = 
    {
     "Account":
      [
        {argument_name: "f_a_type_id", type: "Int", default: 0, function_name: "by_account_type"},
      ],
     "State":
      [
        {argument_name: "f_country_id", type: "Int", default: 0, function_name: "by_country"},
      ],
     "Color":
      [
        {argument_name: "f_material_id", type: "Int", default: 0, function_name: "by_material"},
      ],
     "GemClarity":
      [
        {argument_name: "f_material_id", type: "Int", default: 0, function_name: "by_material"},
      ],
     "GemShape":
      [
        {argument_name: "f_material_id", type: "Int", default: 0, function_name: "by_material"},
      ],
     "GemSize": 
      [
        {argument_name: "f_material_id", type: "Int", default: 0, function_name: "by_filter"},
        {argument_name: "f_gem_shape_id", type: "Int", default: 0, function_name: "by_filter"},
        {argument_name: "f_gem_clarity_id", type: "Int", default: 0, function_name: "gem_clarity"},
      ],
     "Locker":
      [
        {argument_name: "f_location_id", type: "Int", default: 0, function_name: "by_location"},
      ],
     "Material":
      [
        {argument_name: "f_m_type_id", type: "Int", default: 0, function_name: "by_material_type"},
      ],
     "MetalPurity":
      [
        {argument_name: "f_material_id", type: "Int", default: 0, function_name: "by_material"},
      ],
     "RateOn":
      [
        {argument_name: "f_m_type_id", type: "Int", default: 0, function_name: "by_material_type"},
      ],
    }
    a = ""
    
    if arguments[@CS.to_sym] && arguments[@CS] != ''
      arguments[@CS.to_sym].map do |o|
        a += "    argument :#{o[:argument_name]}, types.#{o[:type]}, default_value: #{o[:default]}\n"
      end
    end

    h = Hash.new(0)
    if arguments[@CS.to_sym] && arguments[@CS] != ''
      arguments[@CS.to_sym].map do |o|
        if h.has_key?(o[:function_name]) 
          h[o[:function_name]].push(o[:argument_name])
        else
          h[o[:function_name]] = [o[:argument_name]]
        end
      end
    end

    b = ''
    h.keys.map do |m|
      b += "      #{@cP} = #{@cP}.#{m}(#{h[m].map do |a1| "args[:#{a1}]" end.join(", ")}) if #{h[m].map do |a2| "args[:#{a2}] > 0" end.join(" && ")}\n"
    end

    r = Hash.new(0)
    r["arg1"] = a.chomp
    r["arg2"] = b.chomp
    r
  end
end
