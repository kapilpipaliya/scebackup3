import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  taxRate: gql`
    fragment TaxRateFragment on UserTaxRate {
      id
      user_tax_type_id { id slug }
      position
      slug
      rate
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_TAX_RATE = gql`
    query getTaxRate($id: ID) {
      taxRate(id: $id) {
        ...TaxRateFragment
      }
    }
    ${fragments.taxRate}
  `;

  const withTaxRate = graphql(GET_TAX_RATE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withTaxRate(WrappedComponent);
}
