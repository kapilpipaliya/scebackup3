import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  priority: gql`
    fragment PriorityPreviewFragment on MfgPriority {
      id
      position
      slug
      priority
      isdefault
      created_at
    }
  `,
};

export const AllPrioritiesQuery = gql`
  query allMfgPrioritiesQuery {
    prioritiesCount
    allMfgPriorities {
      ...PriorityPreviewFragment
    }
  }
  ${fragments.priority}
`;

export default graphql(AllPrioritiesQuery, {
  name: 'priorities',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
