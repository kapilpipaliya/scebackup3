import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withRolesData from '../../../queries/user/roles/rolesQuery';

import ListRoles from './_ListRoles';
import HeadListRoles from './_HeadListRoles';

class AllRoles extends Component {
  componentDidMount() {
    this.props.roles.refetch(); // You can pass variables here.
  }

  render() {
    const { roles: { loading, error }, roles } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListRoles />
        <ListRoles data={roles} />
      </div>
    );
  }
}

export default withRolesData(AllRoles);
