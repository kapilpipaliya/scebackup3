import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import { FormControl, FormControlLabel, FormHelperText } from 'material-ui/Form';
import Switch from 'material-ui/Switch';

const styles = (theme) => ({
  formControl: {
    marginRight: theme.spacing.unit,
    // minWidth: 200,
  },
});

class MySwitch extends React.Component {
  static propTypes = {
    input: PropTypes.object.isRequired,
    meta: PropTypes.object.isRequired,
    label: PropTypes.string,
    onChange2: PropTypes.func,
    classes: PropTypes.object,
  }
  constructor(props) {
    super(props);
    const { label } = this.props;
    this.state = { label: label || '' };
    this.input = this.input.bind(this);
  }

  input() {
    const {
      meta: { touched, error, invalid },
      input,
      onChange2,
    } = this.props;
    const { classes } = this.props;

    const inputChange = (event, checked) => {
      input.onChange(checked);
      // const v = e.target.value==="true"
      if (onChange2) {
        onChange2(checked);
      }
      // console.log(this.props.onChangeF())
    };

    return (
      <FormControl
        className={classes.formControl}
        error={touched && invalid}
        fullWidth
      >
        <FormControlLabel
          control={
            <Switch
              // value={this.state.select_value}
              // //onChange={this.handleChange('select_value')}
              name={input.name}
              // onBlur= {input.onBlur}
              // onChange= {input.onChange}
              // onDragStart= {input.onDragStart}
              // onDrop= {input.onDrop}
              // onFocus= {input.onFocus}
              // value= {input.value}
              checked={input.value}
              onChange={inputChange}
            />
          }
          label={this.state.label}
        />
        {touched &&
        error &&
        <FormHelperText>{error}</FormHelperText>}
      </FormControl>
    );
  }

  render() {
    return (this.input());
  }
}

export default withStyles(styles)(MySwitch);
